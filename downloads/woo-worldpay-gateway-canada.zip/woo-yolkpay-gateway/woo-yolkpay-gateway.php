<?php
/**
 * Plugin Name: WooCommerce YolkPay Gateway (Canada)
 * Plugin URI: https://yolkpay.com/downloads/
 * Description: Yolkpay payment gateway for Canadian Merchants
 * Version: 2.0.0
 * Author: Yolkpay
 * Author URI: https://yolkpay.com/
 * Text Domain: woo-yolkpay-gateway-ca
 * Domain Path: /languages
 */

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 定义插件路径常量
define('YOLKPAY_HOSTED_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('YOLKPAY_HOSTED_PLUGIN_URL', plugin_dir_url(__FILE__));
define('YOLKPAY_HOSTED_VERSION', '2.0.0');
// 本网关面向加拿大 Bookiy 商户，仅支持 CAD 结算。店铺币种必须与此一致，
// 否则网关在结账页不可用（见 YolkPay_WC_Gateway::is_available），交易也按此币种校验。
define('YOLKPAY_SUPPORTED_CURRENCY', 'CAD');

// 最早阶段：注册 WooCommerce Blocks 支持（在 plugins_loaded 之后）
// 使用 plugins_loaded 钩子确保网关类已加载
add_action('plugins_loaded', 'yolkpay_hosted_register_blocks_support', 20);

/**
 * 注册 WooCommerce Blocks 支持
 * 调用 YolkPay_WC_Gateway 类中的方法
 */
function yolkpay_hosted_register_blocks_support() {
    // 检查支付网关类是否已加载
    if (!class_exists('YolkPay_WC_Gateway')) {
        return;
    }

    YolkPay_WC_Gateway::register_blocks_support();
}

// 包含主要类文件
require_once YOLKPAY_HOSTED_PLUGIN_PATH . 'includes/class-yolkpay-hosted-page.php';
require_once YOLKPAY_HOSTED_PLUGIN_PATH . 'includes/api/class-bookiy-payment-service.php';
require_once YOLKPAY_HOSTED_PLUGIN_PATH . 'includes/api/class-bookiy-payment-api.php';
require_once YOLKPAY_HOSTED_PLUGIN_PATH . 'includes/class-yolkpay-settings.php';

// 初始化插件
function init_yolkpay_hosted_plugin() {
    try {
        new YolkpayHostedPage();
    } catch (Exception $e) {
        error_log('[YolkPay Plugin] Error initializing YolkpayHostedPage: ' . $e->getMessage());
    }

    try {
        new BookiyPaymentAPI();
    } catch (Exception $e) {
        error_log('[YolkPay Plugin] Error initializing BookiyPaymentAPI: ' . $e->getMessage());
    }

    try {
        new YolkPaySettings();
    } catch (Exception $e) {
        error_log('[YolkPay Plugin] Error initializing YolkPaySettings: ' . $e->getMessage());
    }

    // 只有在WooCommerce激活时才加载和注册支付网关类
    if (class_exists('WC_Payment_Gateway')) {
        require_once YOLKPAY_HOSTED_PLUGIN_PATH . 'includes/class-yolkpay-wc-gateway.php';
        add_filter('woocommerce_payment_gateways', 'yolkpay_hosted_add_gateway_class');
    }

    // 临时：检查并刷新重写规则（仅在需要时执行一次）
    if (get_option('yolkpay_hosted_rewrite_flushed') !== '2.0') {
        flush_rewrite_rules();
        update_option('yolkpay_hosted_rewrite_flushed', '2.0');
    }
}
add_action('plugins_loaded', 'init_yolkpay_hosted_plugin');

// 添加插件设置链接
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'yolkpay_hosted_plugin_settings_link');
function yolkpay_hosted_plugin_settings_link($links) {
    $settings_link = '<a href="options-general.php?page=yolkpay-payment-settings">' . __('Settings', 'yolkpay-hosted') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}

// 加载语言包
add_action('plugins_loaded', 'yolkpay_hosted_load_textdomain');
function yolkpay_hosted_load_textdomain() {
    load_plugin_textdomain('yolkpay-hosted', false, dirname(plugin_basename(__FILE__)) . '/languages');
}

// 注册 WooCommerce支付网关
function yolkpay_hosted_add_gateway_class($gateways) {
    $gateways[] = 'YolkPay_WC_Gateway';
    return $gateways;
}

// 激活插件时刷新重写规则
register_activation_hook(__FILE__, 'yolkpay_hosted_activation');
function yolkpay_hosted_activation() {
    // 先注册重写规则
    $page = new YolkpayHostedPage();
    $page->add_rewrite_rules();

    // 然后刷新
    flush_rewrite_rules();
}

// 停用插件时清理
register_deactivation_hook(__FILE__, 'yolkpay_hosted_deactivation');
function yolkpay_hosted_deactivation() {
    flush_rewrite_rules();
}