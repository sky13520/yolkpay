<?php

/**
 * Bookiy Payment Service for WordPress
 * Provides payment functionality for the YolkPay Hosted checkout page
 */
class BookiyPaymentService {

    private $api_base_url;
    private $merchant_id;
    private $api_key;  // Public API Key (for frontend)
    private $private_api_key;  // Private API Key (for backend API calls)
    private $debug_enabled;  // Debug log switch

    public function __construct() {
        // 从插件设置中获取API凭证
        $options = get_option('yolkpay_payment_options');

        $this->merchant_id = !empty($options['merchant_id']) ? $options['merchant_id'] : '';
        $this->api_key = !empty($options['api_key']) ? $options['api_key'] : '';
        $this->private_api_key = !empty($options['private_api_key']) ? $options['private_api_key'] : '';
        $this->debug_enabled = isset($options['enable_debug_log']) && $options['enable_debug_log'] === '1';

        // 根据环境设置API基础URL（使用加拿大域名）
        $environment = !empty($options['api_environment']) ? $options['api_environment'] : 'test';
        $this->api_base_url = ($environment === 'production')
            ? 'https://api.bookiy.com'
            : 'https://test-api.bookiy.com';

        // 简化的初始化日志（不再输出详细信息，减少日志冗余）
        // 详细配置在各个方法中按需输出
    }

    /**
     * Debug logging helper
     */
    private function debug_log($message) {
        if ($this->debug_enabled) {
            error_log('[YolkPay Debug] ' . $message);
        }
    }

    /**
     * Create transaction session key
     *
     * @param array $config Session configuration
     * @return array API response
     */
    public function createTransactionSession($config = array()) {
        $default_config = array(
            'duration' => 8,
            'maxTimesApproved' => 4,
            'maxTimesUse' => 10
        );

        $configurations = wp_parse_args($config, $default_config);

        $data = array(
            'merchant' => $this->merchant_id,
            'configurations' => $configurations
        );

        try {
            $response = $this->makeApiRequest('/txnSessions', 'POST', $data);

            if (isset($response['response']['data'][0]['key'])) {
                return array(
                    'status' => 'success',
                    'sessionKey' => $response['response']['data'][0]['key'],
                    'sessionId' => $response['response']['data'][0]['id'],
                    'data' => $response
                );
            } else {
                throw new Exception('Failed to retrieve session key from response');
            }
        } catch (Exception $e) {
            // error_log('YolkPay Hosted (Bookiy): Error creating transaction session - ' . $e->getMessage());
            return array(
                'status' => 'error',
                'message' => $e->getMessage()
            );
        }
    }

    /**
     * Get merchant and session configuration for frontend
     *
     * @param string $order_id Order ID
     * @return array Configuration data
     */
    public function getPaymentConfig($order_id = null, $user_id = null) {
        $this->debug_log('========== GET PAYMENT CONFIG ==========');
        $this->debug_log('Order ID: ' . ($order_id ?: 'null'));
        $this->debug_log('User ID (passed): ' . ($user_id ?: 'null'));

        // 直接返回 API Key（参考官方示例代码）
        $config = array(
            'status' => 'success',
            'merchant' => $this->merchant_id,
            'apiKey' => $this->api_key,
            'environment' => (strpos($this->api_base_url, 'test-api') !== false) ? 'TEST' : 'PRODUCTION',
            'apiBaseUrl' => $this->api_base_url
        );

        // 添加订单相关信息
        if ($order_id && function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);
            if ($order && is_a($order, 'WC_Order')) {
                $config['amount'] = $order->get_total();
                $config['currency'] = $order->get_currency();
                $config['orderId'] = $order_id;
            }
        }

        // 如果没有传递user_id，尝试获取当前登录用户
        if ($user_id === null) {
            $user_id = get_current_user_id();
            $this->debug_log('User ID not passed, using current user: ' . $user_id);
        }

        $this->debug_log('Final user ID to use: ' . $user_id);

        // 优先从订单获取 billing email（checkout 页实际输入的邮箱）
        $billing_email = null;
        if ($order_id && function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);
            if ($order && is_a($order, 'WC_Order')) {
                $billing_email = $order->get_billing_email();
                $this->debug_log('Billing email from order: ' . ($billing_email ?: 'null'));
            }
        }

        // 如果没有订单或订单中没有邮箱，才使用用户资料中的邮箱
        if (!$billing_email && $user_id > 0) {
            $user = get_userdata($user_id);
            if ($user && $user->user_email) {
                $billing_email = $user->user_email;
                $this->debug_log('Fallback to user profile email: ' . $billing_email);
            }
        }

        // 不再在配置阶段创建 customer ID
        // PayFields 会在 txnToken 模式下自动创建 customer（如果设置了 customer 对象）
        if ($billing_email) {
            $this->debug_log('Using email for customer lookup: ' . $billing_email);

            // 仅尝试从缓存获取已存在的customer ID（不创建新的）
            $customer_id = $this->getExistingCustomerId($billing_email);
            $this->debug_log('Cached Customer ID: ' . ($customer_id ?: 'null'));

            if ($customer_id) {
                $config['existingCustomerId'] = $customer_id;
                $this->debug_log('✓ Existing customer ID added to config: ' . $customer_id);
            } else {
                $this->debug_log('✗ No cached customer ID found (will be auto-created by PayFields)');
            }
        } else {
            $this->debug_log('No email available (user not logged in or no order)');
        }

        $this->debug_log('Final config: ' . json_encode($config));
        $this->debug_log('========== END GET PAYMENT CONFIG ==========');

        return $config;
    }

    /**
     * 仅获取已存在的 Customer ID（不创建新的）
     *
     * @param string $email 用户邮箱
     * @return string|null Customer ID
     */
    private function getExistingCustomerId($email) {
        try {
            // 获取当前环境标识
            $current_env = (strpos($this->api_base_url, 'test-api') !== false) ? 'test' : 'production';

            // 从 user meta 中获取缓存
            $user = get_user_by('email', $email);
            if (!$user) {
                return null;
            }

            // 使用环境特定的 meta key
            $meta_key = 'bookiy_customer_id_' . $current_env;
            $cached_customer_id = get_user_meta($user->ID, $meta_key, true);

            if (!$cached_customer_id) {
                return null;
            }

            // 验证缓存的 customer ID 是否匹配当前环境
            $customer_prefix = substr($cached_customer_id, 0, 3); // t1_ 或 p1_
            $expected_prefix = ($current_env === 'test') ? 't1_' : 'p1_';

            if ($customer_prefix !== $expected_prefix) {
                // 前缀不匹配，清除缓存
                delete_user_meta($user->ID, $meta_key);
                return null;
            }

            return $cached_customer_id;

        } catch (Exception $e) {
            return null;
        }
    }

    /**
     * 获取用户的所有Tokens（从Pay rix API）
     *
     * @param string $email 用户邮箱
     * @return array Tokens数组
     */
    public function getTokensForUser($email) {
        try {
            // error_log('========== GET TOKENS FOR USER ==========');
            // error_log('Email: ' . $email);

            // 只查询已存在的customer ID，不创建（避免页面加载时创建 customer）
            $customer_id = $this->getExistingCustomerId($email);
            if (!$customer_id) {
                // error_log('No customer ID found for email: ' . $email);
                // error_log('========== END GET TOKENS ==========');
                return array();
            }

            // error_log('!!! Using customer ID: ' . $customer_id . ' for email: ' . $email);
            // error_log('Fetching tokens for customer: ' . $customer_id);

            // 查询该customer的所有tokens，按创建时间降序排序，只获取最近10个
            $tokens_endpoint = '/tokens?filter[customer]=' . urlencode($customer_id) . '&embed=payment&sort=-created&page[size]=10';
            $response = $this->makeApiRequest($tokens_endpoint, 'GET', array(), true); // 使用Private Key

            // error_log('Tokens API response: ' . json_encode($response, JSON_PRETTY_PRINT));

            $tokens_data = array();
            if (isset($response['response']['data'])) {
                $tokens_data = $response['response']['data'];
            } elseif (isset($response['data'])) {
                $tokens_data = $response['data'];
            }

            // error_log('API returned ' . count($tokens_data) . ' tokens, filtering by customer ID: ' . $customer_id);

            // 格式化tokens，并添加过滤逻辑
            $formatted_tokens = array();
            $seen_last4 = array(); // 用于去重，避免显示多个相同的卡

            foreach ($tokens_data as $token) {
                // !!!关键过滤：只保留属于当前customer的tokens
                $token_customer = isset($token['customer']) ? $token['customer'] : '';
                if ($token_customer !== $customer_id) {
                    continue; // 静默跳过不属于当前customer的token
                }

                // 跳过inactive或frozen的tokens
                if (isset($token['inactive']) && $token['inactive'] == 1) {
                    continue;
                }
                if (isset($token['frozen']) && $token['frozen'] == 1) {
                    continue;
                }

                // 跳过pending状态的tokens
                if (isset($token['status']) && $token['status'] === 'pending') {
                    continue;
                }

                $payment_info = isset($token['payment']) ? $token['payment'] : array();
                $last4 = isset($payment_info['number']) ? $payment_info['number'] : '';

                // 跳过没有last4的token
                if (empty($last4)) {
                    continue;
                }

                // 去重：如果已经有相同last4的卡，跳过
                if (isset($seen_last4[$last4])) {
                    continue;
                }

                $seen_last4[$last4] = true;

                $formatted_tokens[] = array(
                    'token_id' => $token['id'],
                    'last4' => $last4,
                    'brand' => isset($payment_info['type']) ? $payment_info['type'] : 'card',
                    'exp_month' => '',
                    'exp_year' => '',
                    'cardholder_name' => '',
                    'created_at' => isset($token['created']) ? $token['created'] : ''
                );

                // 最多返回3个有效的不同卡片
                if (count($formatted_tokens) >= 3) {
                    break;
                }
            }

            // error_log('Formatted ' . count($formatted_tokens) . ' tokens for customer: ' . $customer_id);
            return $formatted_tokens;

        } catch (Exception $e) {
            // error_log('Error getting tokens for user: ' . $e->getMessage());
            return array();
        }
    }

    /**
     * 获取或创建Bookiy Customer ID
     *
     * @param string $email 用户邮箱
     * @param string $first_name 名
     * @param string $last_name 姓
     * @return string|null Customer ID
     */
    private function getOrCreateCustomerId($email, $first_name = '', $last_name = '') {
        try {
            $this->debug_log('========== GET OR CREATE CUSTOMER ==========');
            $this->debug_log('Email: ' . $email);

            // 获取当前环境标识
            $current_env = (strpos($this->api_base_url, 'test-api') !== false) ? 'test' : 'production';
            $this->debug_log('Current environment: ' . $current_env);

            // 先尝试从 user meta 中获取
            $user = get_user_by('email', $email);
            if ($user) {
                $this->debug_log('WordPress User found: ID=' . $user->ID . ', Email=' . $user->user_email);

                // 使用环境特定的 meta key
                $meta_key = 'bookiy_customer_id_' . $current_env;
                $cached_customer_id = get_user_meta($user->ID, $meta_key, true);

                if ($cached_customer_id) {
                    $this->debug_log('Using CACHED customer ID (' . $current_env . '): ' . $cached_customer_id . ' for user: ' . $user->ID);

                    // 验证缓存的 customer ID 是否匹配当前环境
                    $customer_prefix = substr($cached_customer_id, 0, 3); // t1_ 或 p1_
                    $expected_prefix = ($current_env === 'test') ? 't1_' : 'p1_';

                    if ($customer_prefix === $expected_prefix) {
                        $this->debug_log('✓ Cached customer ID matches current environment');
                        $this->debug_log('========== END GET OR CREATE CUSTOMER ==========');
                        return $cached_customer_id;
                    } else {
                        $this->debug_log('⚠ WARNING: Cached customer ID prefix (' . $customer_prefix . ') does not match expected (' . $expected_prefix . ')');
                        $this->debug_log('Clearing invalid cache and creating new customer...');
                        delete_user_meta($user->ID, $meta_key);
                    }
                } else {
                    $this->debug_log('No cached customer ID for user: ' . $user->ID . ' (env: ' . $current_env . ')');
                }
            } else {
                $this->debug_log('WARNING: WordPress user not found for email: ' . $email);
            }

            // 策略：直接尝试创建customer，如果email已存在，Bookiy会返回错误，然后我们再查询
            $this->debug_log('Attempting to create new customer directly...');

            $customer_data = array(
                'merchant' => $this->merchant_id,
                'email' => $email,
                'first' => $first_name ?: 'Customer',
                'last' => $last_name ?: 'User',
            );

            $this->debug_log('Creating customer with data: ' . json_encode($customer_data));

            $create_response = $this->makeApiRequest('/customers', 'POST', $customer_data, true);
            $this->debug_log('Create customer response: ' . json_encode($create_response, JSON_PRETTY_PRINT));

            // 检查是否创建成功
            $customer_id = null;
            if (isset($create_response['response']['data'][0]['id'])) {
                $customer_id = $create_response['response']['data'][0]['id'];
                $this->debug_log('NEW customer created successfully: ' . $customer_id);
            } elseif (isset($create_response['data'][0]['id'])) {
                $customer_id = $create_response['data'][0]['id'];
                $this->debug_log('NEW customer created successfully: ' . $customer_id);
            }

            // 如果创建成功，缓存并返回
            if ($customer_id) {
                if ($user) {
                    $meta_key = 'bookiy_customer_id_' . $current_env;
                    update_user_meta($user->ID, $meta_key, $customer_id);
                    $this->debug_log('Cached NEW customer ID to user meta (' . $current_env . '): User ' . $user->ID . ' => Customer ' . $customer_id);
                }
                $this->debug_log('========== END GET OR CREATE CUSTOMER ==========');
                return $customer_id;
            }

            // 创建失败，检查是否是因为email已存在
            $errors = array();
            if (isset($create_response['response']['errors'])) {
                $errors = $create_response['response']['errors'];
            } elseif (isset($create_response['errors'])) {
                $errors = $create_response['errors'];
            }

            $this->debug_log('Customer creation failed, errors: ' . json_encode($errors));

            // 如果是email已存在的错误，则查询所有customers并手动匹配
            $email_exists = false;
            foreach ($errors as $error) {
                if (isset($error['field']) && $error['field'] === 'email') {
                    $email_exists = true;
                    $this->debug_log('Email already exists in Bookiy, will search for existing customer');
                    break;
                }
            }

            if ($email_exists) {
                // 获取所有customers（不使用filter，因为filter不可靠）
                $this->debug_log('Fetching ALL customers to find matching email...');
                $all_customers_response = $this->makeApiRequest('/customers?page[size]=100', 'GET', array(), true);

                $all_customers = array();
                if (isset($all_customers_response['response']['data'])) {
                    $all_customers = $all_customers_response['response']['data'];
                } elseif (isset($all_customers_response['data'])) {
                    $all_customers = $all_customers_response['data'];
                }

                $this->debug_log('Retrieved ' . count($all_customers) . ' customers, searching for email match...');

                // 遍历所有customers，找到email匹配的
                foreach ($all_customers as $cust) {
                    $cust_email = isset($cust['email']) ? $cust['email'] : '';
                    if (!empty($cust_email) && strtolower($cust_email) === strtolower($email)) {
                        $customer_id = $cust['id'];
                        $this->debug_log('✓ Found existing customer with matching email: ' . $customer_id);

                        // 缓存
                        if ($user) {
                            $meta_key = 'bookiy_customer_id_' . $current_env;
                            update_user_meta($user->ID, $meta_key, $customer_id);
                            $this->debug_log('Cached customer ID to user meta (' . $current_env . '): User ' . $user->ID . ' => Customer ' . $customer_id);
                        }
                        $this->debug_log('========== END GET OR CREATE CUSTOMER ==========');
                        return $customer_id;
                    }
                }

                $this->debug_log('ERROR: Email exists error but could not find matching customer!');
            }

            $this->debug_log('ERROR: Failed to create or find customer');
            $this->debug_log('========== END GET OR CREATE CUSTOMER ==========');
            return null;

        } catch (Exception $e) {
            $this->debug_log('Error getting/creating customer ID: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * 从交易响应中保存 customer ID
     * 在支付成功后调用，从交易数据中提取并缓存 customer ID
     *
     * @param string $transaction_id 交易ID
     * @param int $user_id 用户ID
     * @param string $user_email 用户邮箱（后备）
     * @return array Response data
     */
    public function saveCustomerIdFromTransaction($transaction_id, $user_id = null, $user_email = null) {
        try {
            $this->debug_log('========== SAVE CUSTOMER ID FROM TRANSACTION ==========');
            $this->debug_log('Transaction ID: ' . $transaction_id);
            $this->debug_log('User ID: ' . ($user_id ?: 'null'));
            $this->debug_log('User Email: ' . ($user_email ?: 'null'));

            // 获取交易详情
            $txn_response = $this->makeApiRequest('/txns/' . $transaction_id . '?embed=token', 'GET', array(), true);
            $this->debug_log('Transaction response: ' . json_encode($txn_response, JSON_PRETTY_PRINT));

            $txn_data = null;
            if (isset($txn_response['response']['data'][0])) {
                $txn_data = $txn_response['response']['data'][0];
            } elseif (isset($txn_response['data'][0])) {
                $txn_data = $txn_response['data'][0];
            }

            if (!$txn_data) {
                throw new Exception('Transaction data not found');
            }

            // 从交易数据中提取 customer ID
            $customer_id = null;

            // 方法1: 直接从交易的 customer 字段获取
            if (isset($txn_data['customer']) && !empty($txn_data['customer'])) {
                $customer_id = $txn_data['customer'];
                $this->debug_log('Found customer ID from txn.customer: ' . $customer_id);
            }
            // 方法2: 从嵌入的 token 数据中获取
            elseif (isset($txn_data['token']) && is_array($txn_data['token']) && isset($txn_data['token']['customer'])) {
                $customer_id = $txn_data['token']['customer'];
                $this->debug_log('Found customer ID from txn.token.customer: ' . $customer_id);
            }

            if (!$customer_id) {
                $this->debug_log('WARNING: Customer ID not found in transaction data');
                return array(
                    'status' => 'error',
                    'message' => 'Customer ID not found in transaction'
                );
            }

            // 获取当前环境
            $current_env = (strpos($this->api_base_url, 'test-api') !== false) ? 'test' : 'production';
            $this->debug_log('Current environment: ' . $current_env);

            // 验证 customer ID 前缀是否匹配环境
            $customer_prefix = substr($customer_id, 0, 3);
            $expected_prefix = ($current_env === 'test') ? 't1_' : 'p1_';

            if ($customer_prefix !== $expected_prefix) {
                $this->debug_log('ERROR: Customer ID prefix (' . $customer_prefix . ') does not match environment (' . $expected_prefix . ')');
                return array(
                    'status' => 'error',
                    'message' => 'Customer ID environment mismatch'
                );
            }

            // 优先使用 user_id 获取用户，如果没有再尝试用 email
            $user = null;
            if ($user_id && $user_id > 0) {
                $user = get_userdata($user_id);
                $this->debug_log('Lookup user by ID ' . $user_id . ': ' . ($user ? 'Found' : 'Not found'));
            }

            // 如果通过 ID 没找到，尝试用 email
            if (!$user && $user_email) {
                $user = get_user_by('email', $user_email);
                $this->debug_log('Fallback: Lookup user by email ' . $user_email . ': ' . ($user ? 'Found' : 'Not found'));
            }

            if (!$user) {
                $this->debug_log('WARNING: WordPress user not found');
                return array(
                    'status' => 'error',
                    'message' => 'User not found'
                );
            }

            $meta_key = 'bookiy_customer_id_' . $current_env;
            $existing_customer_id = get_user_meta($user->ID, $meta_key, true);

            if ($existing_customer_id && $existing_customer_id === $customer_id) {
                $this->debug_log('Customer ID already cached: ' . $customer_id);
            } else {
                update_user_meta($user->ID, $meta_key, $customer_id);
                $this->debug_log('✓ Cached customer ID: User ' . $user->ID . ' => Customer ' . $customer_id . ' (env: ' . $current_env . ')');
            }

            $this->debug_log('========== END SAVE CUSTOMER ID ==========');

            return array(
                'status' => 'success',
                'customer_id' => $customer_id,
                'environment' => $current_env
            );

        } catch (Exception $e) {
            $this->debug_log('Error saving customer ID: ' . $e->getMessage());
            return array(
                'status' => 'error',
                'message' => $e->getMessage()
            );
        }
    }

    /**
     * Process payment notification from Bookiy
     *
     * @param array $notification_data Notification data
     * @return array Response data
     */
    public function processNotification($notification_data) {
        // error_log('YolkPay Hosted (Bookiy) Payment - Notification received: ' . json_encode($notification_data));

        try {
            // 验证通知数据
            if (!isset($notification_data['id']) || !isset($notification_data['status'])) {
                throw new Exception('Invalid notification data');
            }

            $transaction_id = $notification_data['id'];

            // error_log('YolkPay Hosted (Bookiy) Payment - Transaction ID: ' . $transaction_id);

            // 从 customFields 或 merchant_reference 中获取订单ID
            $order_id = null;
            if (isset($notification_data['customFields']['order_id'])) {
                $order_id = $notification_data['customFields']['order_id'];
            } elseif (isset($notification_data['merchant_reference'])) {
                $order_id = $notification_data['merchant_reference'];
            }

            if (!$order_id || !function_exists('wc_get_order')) {
                return array(
                    'status' => 'pending',
                    'message' => 'No resolvable order for notification'
                );
            }

            $order = wc_get_order($order_id);
            if (!$order || !is_a($order, 'WC_Order')) {
                return array(
                    'status' => 'pending',
                    'message' => 'Order not found'
                );
            }

            // 安全：Webhook 无签名密钥，不能信任通知体中的 status。
            // 按交易ID重新向 Bookiy 拉取并复核（状态/金额/币种），通过后再改单；并做重放保护。
            $verification = $this->verifyTransaction($transaction_id, $order);
            if (!$verification['ok']) {
                return array(
                    'status' => 'pending',
                    'message' => 'Notification transaction not verified'
                );
            }

            if (!$this->claimTransaction($transaction_id, $order->get_id())) {
                return array(
                    'status' => 'pending',
                    'message' => 'Transaction already used'
                );
            }

            if (in_array($order->get_status(), array('pending', 'on-hold'), true)) {
                $order->update_meta_data('_bookiy_consumed_txn', $transaction_id);
                $order->save();
                $this->updateOrderStatus($order_id, 'success', $transaction_id);
                $this->cacheCustomerIdForOrderUser($order, $verification['customer_id']);
            }

            return array(
                'status' => 'success',
                'message' => 'Payment notification processed successfully'
            );
        } catch (Exception $e) {
            // error_log('YolkPay Hosted (Bookiy) Payment - Error processing notification: ' . $e->getMessage());
            return array(
                'status' => 'error',
                'message' => $e->getMessage()
            );
        }
    }

    /**
     * Update WooCommerce order status synchronously (called from frontend)
     *
     * @param string $order_id Order ID
     * @param string $transaction_id Transaction ID
     * @return array Response data
     */
    public function updateOrderStatusSync($order_id, $transaction_id) {
        // error_log('YolkPay Hosted (Bookiy) Payment - Sync update order: ' . $order_id . ', Transaction: ' . $transaction_id);

        if (!function_exists('wc_get_order')) {
            // error_log('YolkPay Hosted (Bookiy) Payment - WooCommerce not active');
            return array(
                'status' => 'error',
                'message' => 'WooCommerce not active'
            );
        }

        try {
            $order = wc_get_order($order_id);
            if (!$order || !is_a($order, 'WC_Order')) {
                // error_log('YolkPay Hosted (Bookiy) Payment - Invalid order ID: ' . $order_id);
                return array(
                    'status' => 'error',
                    'message' => 'Invalid order ID'
                );
            }

            $current_status = $order->get_status();
            // error_log('YolkPay Hosted (Bookiy) Payment - Current order status: ' . $current_status);

            // 只有当订单状态为待付款或on-hold时才更新
            if ($current_status === 'pending' || $current_status === 'on-hold') {
                // 安全：服务端独立向 Bookiy 复核交易（状态/金额/币种），不信任前端提交的金额与状态。
                $verification = $this->verifyTransaction($transaction_id, $order);
                if (!$verification['ok']) {
                    $order->add_order_note(__('Payment verification failed: ', 'yolkpay-hosted') . $verification['message']);
                    return array(
                        'status' => 'error',
                        'message' => 'Transaction verification failed'
                    );
                }

                // 安全：原子化重放保护，拒绝把同一笔交易用于多个订单。
                if (!$this->claimTransaction($transaction_id, $order->get_id())) {
                    $order->add_order_note(__('Payment rejected: transaction already used for another order.', 'yolkpay-hosted'));
                    return array(
                        'status' => 'error',
                        'message' => 'Transaction already used'
                    );
                }

                // 获取设置的订单状态
                $options = get_option('yolkpay_payment_options');
                $target_status = isset($options['payment_success_status']) ? $options['payment_success_status'] : 'completed';

                // 添加交易ID到订单，并标记该交易已被本订单消费（重放保护用）
                if ($transaction_id) {
                    $order->set_transaction_id($transaction_id);
                    $order->update_meta_data('_bookiy_consumed_txn', $transaction_id);
                    $order->save();
                }

                // 更新订单状态
                $order->update_status($target_status, __('Payment completed via YolkPay Hosted (Bookiy) - Synchronous update.', 'yolkpay-hosted'));
                // error_log('YolkPay Hosted (Bookiy) Payment - Order status updated to ' . $target_status . ' for order: ' . $order_id);

                // 减少库存
                if (function_exists('wc_reduce_stock_levels')) {
                    wc_reduce_stock_levels($order_id);
                    // error_log('YolkPay Hosted (Bookiy) Payment - Stock reduced for order: ' . $order_id);
                }

                // 服务端可靠缓存 customer id（修复前端 fire-and-forget 竞态）
                $this->cacheCustomerIdForOrderUser($order, $verification['customer_id']);

                return array(
                    'status' => 'success',
                    'message' => 'Order status updated successfully',
                    'order_status' => $target_status
                );
            } else {
                // error_log('YolkPay Hosted (Bookiy) Payment - Order status not updated. Current status: ' . $current_status);
                return array(
                    'status' => 'skipped',
                    'message' => 'Order status is not pending or on-hold',
                    'current_status' => $current_status
                );
            }
        } catch (Exception $e) {
            // error_log('YolkPay Hosted (Bookiy) Payment - Error updating order status: ' . $e->getMessage());
            return array(
                'status' => 'error',
                'message' => $e->getMessage()
            );
        }
    }

    /**
     * Update WooCommerce order status
     *
     * @param string $order_id Order ID
     * @param string $status Payment status
     * @param string $transaction_id Transaction ID
     */
    private function updateOrderStatus($order_id, $status, $transaction_id = '') {
        if (!function_exists('wc_get_order')) {
            // error_log('YolkPay Hosted (Bookiy) Payment - WooCommerce not active');
            return;
        }

        try {
            $order = wc_get_order($order_id);
            if ($order && is_a($order, 'WC_Order')) {
                $current_status = $order->get_status();
                // error_log('YolkPay Hosted (Bookiy) Payment - Current order status: ' . $current_status);

                if (($current_status === 'pending' || $current_status === 'on-hold') && $status === 'success') {
                    // 获取设置的订单状态
                    $options = get_option('yolkpay_payment_options');
                    $target_status = isset($options['payment_success_status']) ? $options['payment_success_status'] : 'completed';

                    // 添加交易ID到订单
                    if ($transaction_id) {
                        $order->set_transaction_id($transaction_id);
                    }

                    // 更新订单状态
                    $order->update_status($target_status, __('Payment completed via YolkPay Hosted (Bookiy).', 'yolkpay-hosted'));
                    // error_log('YolkPay Hosted (Bookiy) Payment - Order status updated to ' . $target_status . ' for order: ' . $order_id);

                    // 减少库存
                    if (function_exists('wc_reduce_stock_levels')) {
                        wc_reduce_stock_levels($order_id);
                        // error_log('YolkPay Hosted (Bookiy) Payment - Stock reduced for order: ' . $order_id);
                    }
                }
            }
        } catch (Exception $e) {
            // error_log('YolkPay Hosted (Bookiy) Payment - Error updating order status: ' . $e->getMessage());
        }
    }

    /**
     * 服务端独立向 Bookiy 复核一笔交易，确认它真实存在、已成功、且金额/币种与订单一致。
     *
     * 这是阻断「任意访客用伪造 transactionId 把订单标记为已支付」的核心防线：
     * 新卡 PayFields 流程的交易在客户端创建，金额与状态都不可信，必须由服务端用 private key
     * 重新拉取交易来确认。金额（分）相等是最稳定的反欺诈控制；状态成功集合可能需要按 Bookiy/Bookiy
     * 实际返回的取值微调（已尽量覆盖字符串与数值两种编码）。
     *
     * @param string   $transaction_id 交易ID
     * @param WC_Order $order          对应订单
     * @return array { ok: bool, message: string, customer_id: string|null }
     */
    private function verifyTransaction($transaction_id, $order) {
        if (empty($transaction_id)) {
            return array('ok' => false, 'message' => 'Missing transaction id', 'customer_id' => null);
        }

        try {
            $txn_response = $this->makeApiRequest('/txns/' . rawurlencode($transaction_id) . '?embed=token', 'GET', array(), true);
        } catch (Exception $e) {
            return array('ok' => false, 'message' => 'Unable to verify transaction: ' . $e->getMessage(), 'customer_id' => null);
        }

        $txn = null;
        if (isset($txn_response['response']['data'][0])) {
            $txn = $txn_response['response']['data'][0];
        } elseif (isset($txn_response['data'][0])) {
            $txn = $txn_response['data'][0];
        }

        if (!is_array($txn)) {
            return array('ok' => false, 'message' => 'Transaction not found', 'customer_id' => null);
        }

        // 金额校验（分）。Bookiy /txns 的 total 单位为分。
        $expected_cents = (int) round(((float) $order->get_total()) * 100);
        $txn_cents = isset($txn['total']) ? (int) $txn['total'] : -1;
        if ($txn_cents !== $expected_cents) {
            return array(
                'ok' => false,
                'message' => 'Transaction amount mismatch (expected ' . $expected_cents . ', got ' . $txn_cents . ')',
                'customer_id' => null,
            );
        }

        // 币种一致校验（强制）：本网关仅支持 YOLKPAY_SUPPORTED_CURRENCY（CAD）结算，
        // 且在非该币种的店铺下不可用（见 YolkPay_WC_Gateway::is_available），
        // 因此交易币种必须等于该币种，否则拒绝。这样既保证一致性，又不会误杀。
        $expected_currency = defined('YOLKPAY_SUPPORTED_CURRENCY') ? YOLKPAY_SUPPORTED_CURRENCY : 'CAD';
        if (isset($txn['currency']) && is_string($txn['currency']) && $txn['currency'] !== ''
            && strtoupper($txn['currency']) !== strtoupper($expected_currency)) {
            return array(
                'ok' => false,
                'message' => 'Transaction currency mismatch (expected ' . strtoupper($expected_currency) . ', got ' . strtoupper($txn['currency']) . ')',
                'customer_id' => null,
            );
        }

        // 订单绑定校验（强制 / fail-closed）：交易**必须**自带订单引用，且与本订单ID一致。
        // 仅凭金额/币种/时间无法证明「这笔交易就是为这张订单付的款」——必须有显式订单引用。
        // 引用来源：token 支付由服务端写入 txn.order；新卡 PayFields 由 PayFields.config.order 写入。
        // 缺失引用、或引用与本订单不一致：一律拒绝（webhook 路径无 order_key，更依赖此校验）。
        $txn_order_ref = '';
        if (isset($txn['order']) && is_scalar($txn['order'])) {
            $txn_order_ref = (string) $txn['order'];
        } elseif (isset($txn['merchant_reference']) && is_scalar($txn['merchant_reference'])) {
            $txn_order_ref = (string) $txn['merchant_reference'];
        } elseif (isset($txn['customFields']['order_id']) && is_scalar($txn['customFields']['order_id'])) {
            $txn_order_ref = (string) $txn['customFields']['order_id'];
        }
        if ($txn_order_ref === '') {
            return array(
                'ok' => false,
                'message' => 'Transaction has no order reference; cannot bind to order',
                'customer_id' => null,
            );
        }
        if ($txn_order_ref !== (string) $order->get_id()) {
            return array(
                'ok' => false,
                'message' => 'Transaction does not belong to this order',
                'customer_id' => null,
            );
        }

        // 说明：不再做「交易创建时间晚于订单」的新鲜度检查。
        // 订单引用（txn.order == 订单ID）已是强制条件，足以把交易唯一绑定到这张订单；
        // 而 Bookiy 的 created 字段是美东时区且无时区后缀，用 strtotime 按服务器时区(UTC)解析会
        // 产生数小时偏差，导致正常支付被误判为「早于订单」。绑定由订单引用 + 金额 + 状态 + 重放保证。

        // 状态校验（白名单 / 默认拒绝）：必须处于明确的成功状态才放行；
        // 失败/撤销/退款拒绝，pending/未知/新增的任何状态一律默认拒绝。
        // approved 金额不再作为成功依据。白名单取值需按 Bookiy/Bookiy 实际 /txns 返回核对微调。
        $status = isset($txn['status']) ? $txn['status'] : '';
        $status_str = is_scalar($status) ? strtolower((string) $status) : '';

        $success_statuses = array('approved', 'captured', 'capture', 'settled', 'success', 'complete', 'completed');
        $success_numeric = array('1', '3', '4', 1, 3, 4); // Bookiy: 1=approved,3=captured,4=settled
        $is_success = in_array($status_str, $success_statuses, true)
            || in_array($status, $success_numeric, true);
        if (!$is_success) {
            return array(
                'ok' => false,
                'message' => 'Transaction not in an explicitly successful state (status: ' . ($status_str !== '' ? $status_str : 'unknown') . ')',
                'customer_id' => null,
            );
        }

        // 提取 customer id（供改单成功后服务端可靠缓存，修复前端竞态）。
        $customer_id = null;
        if (isset($txn['customer']) && !empty($txn['customer']) && is_string($txn['customer'])) {
            $customer_id = $txn['customer'];
        } elseif (isset($txn['token']['customer']) && !empty($txn['token']['customer'])) {
            $customer_id = $txn['token']['customer'];
        }

        return array('ok' => true, 'message' => 'verified', 'customer_id' => $customer_id);
    }

    /**
     * 原子化重放保护：为交易认领唯一归属订单。
     *
     * 用 WordPress options 表（option_name 有唯一索引）做原子认领：并发请求下
     * `add_option` 只有一个会成功，从而保证同一交易不会被两个订单同时通过校验
     * —— 修复「先查询后写入」两步操作之间的竞态。
     *
     * @param string $transaction_id 交易ID
     * @param int    $current_order_id 当前订单ID
     * @return bool true 表示本订单成功认领（或此前已由本订单认领，幂等重试）
     */
    private function claimTransaction($transaction_id, $current_order_id) {
        if (empty($transaction_id)) {
            return false;
        }
        $key = '_bookiy_txn_claim_' . md5($transaction_id);
        // autoload=no，避免认领记录拖慢每次请求。
        $claimed = add_option($key, (string) $current_order_id, '', 'no');
        if ($claimed) {
            return true;
        }
        // 已被认领：仅当认领者就是本订单（重试/幂等）时放行，否则判定为重放。
        return ((string) get_option($key) === (string) $current_order_id);
    }

    /**
     * 改单成功后，将已核验交易中的 customer id 可靠缓存到订单所属用户（服务端，避免前端竞态）。
     *
     * @param WC_Order $order       订单
     * @param string   $customer_id Bookiy customer id
     */
    private function cacheCustomerIdForOrderUser($order, $customer_id) {
        if (empty($customer_id)) {
            return;
        }
        $user_id = $order->get_user_id();
        if (!$user_id) {
            return;
        }
        $current_env = (strpos($this->api_base_url, 'test-api') !== false) ? 'test' : 'production';
        $expected_prefix = ($current_env === 'test') ? 't1_' : 'p1_';
        if (substr($customer_id, 0, 3) !== $expected_prefix) {
            return;
        }
        $meta_key = 'bookiy_customer_id_' . $current_env;
        update_user_meta($user_id, $meta_key, $customer_id);
    }

    /**
     * Make API request to Bookiy
     *
     * @param string $endpoint API endpoint
     * @param string $method HTTP method
     * @param array $data Request data
     * @param bool $use_private_key Whether to use private API key
     * @return array Response data
     */
    private function makeApiRequest($endpoint, $method = 'GET', $data = array(), $use_private_key = false) {
        $url = $this->api_base_url . $endpoint;

        // 选择使用哪个API Key
        $api_key = $use_private_key ? $this->private_api_key : $this->api_key;

        if (empty($api_key)) {
            $key_type = $use_private_key ? 'Private' : 'Public';
            $this->debug_log('ERROR: ' . $key_type . ' API Key is not configured');
            throw new Exception($key_type . ' API Key is not configured');
        }

        $args = array(
            'method' => $method,
            'headers' => array(
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'APIKEY' => $api_key
            ),
            'timeout' => 30
        );

        if ($method === 'POST' && !empty($data)) {
            $args['body'] = json_encode($data);
        }

        $this->debug_log('========== API REQUEST ==========');
        $this->debug_log('URL: ' . $url);
        $this->debug_log('Method: ' . $method);
        $this->debug_log('Using: ' . ($use_private_key ? 'Private' : 'Public') . ' Key');
        if ($method === 'POST' && !empty($data)) {
            $this->debug_log('Request Data: ' . json_encode($data, JSON_PRETTY_PRINT));
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            $this->debug_log('ERROR: ' . $response->get_error_message());
            throw new Exception($response->get_error_message());
        }

        $body = wp_remote_retrieve_body($response);
        $decoded = json_decode($body, true);

        $this->debug_log('Response Status: ' . wp_remote_retrieve_response_code($response));
        $this->debug_log('Response Body: ' . $body);
        $this->debug_log('========== END API REQUEST ==========');

        return $decoded;
    }

    /**
     * 使用Token进行支付
     *
     * @param string $order_id 订单ID
     * @param string $token_id Token ID
     * @return array 响应数据
     */
    public function payWithToken($order_id, $token_id, $user_id = 0) {
        // error_log('BookiyPaymentService - Pay with token');
        // error_log('Order ID: ' . $order_id);
        // error_log('Token ID: ' . $token_id);

        try {
            // 安全：必须是已登录用户，且该 token 必须属于该用户名下的 Bookiy customer，
            // 否则任何人都能用别人保存的卡为自己的订单扣款。
            $user_id = (int) $user_id;
            if ($user_id <= 0) {
                throw new Exception('Authentication required to pay with a saved card');
            }
            $current_env = (strpos($this->api_base_url, 'test-api') !== false) ? 'test' : 'production';
            $owner_customer_id = get_user_meta($user_id, 'bookiy_customer_id_' . $current_env, true);
            if (empty($owner_customer_id)) {
                throw new Exception('No saved cards found for this account');
            }
            // 首先验证Token是否有效
            // error_log('Validating token...');
            $token_check = $this->makeApiRequest('/tokens/' . $token_id, 'GET', array(), true);
            // error_log('Token validation response: ' . json_encode($token_check, JSON_PRETTY_PRINT));

            $token_data = null;
            if (isset($token_check['response']['data'][0])) {
                $token_data = $token_check['response']['data'][0];
            } elseif (isset($token_check['data'][0])) {
                $token_data = $token_check['data'][0];
            }

            if (!$token_data) {
                throw new Exception('Token not found: ' . $token_id);
            }

            $token_status = isset($token_data['status']) ? $token_data['status'] : 'unknown';
            // error_log('Token status: ' . $token_status);

            // 检查是否为pending状态
            if ($token_status === 'pending') {
                throw new Exception('Token is still pending activation. Please wait a moment and try again.');
            }

            // 检查是否为inactive或frozen
            if (isset($token_data['inactive']) && $token_data['inactive'] == 1) {
                throw new Exception('Token is inactive and cannot be used for payment');
            }

            if (isset($token_data['frozen']) && $token_data['frozen'] == 1) {
                throw new Exception('Token is frozen and cannot be used for payment');
            }

            // error_log('Token is valid and ready for payment');

            // 安全：确认该 token 归属当前登录用户名下的 customer（防止盗用他人保存的卡）。
            $token_customer = isset($token_data['customer']) ? $token_data['customer'] : '';
            if (empty($token_customer) || $token_customer !== $owner_customer_id) {
                throw new Exception('This saved card does not belong to your account');
            }

            // DEBUG: 检查token的merchant
            // error_log('DEBUG - Token data analysis:');
            // error_log('  Token ID: ' . $token_data['id']);
            // error_log('  Token customer: ' . (isset($token_data['customer']) ? $token_data['customer'] : 'N/A'));
            // error_log('  Token created: ' . (isset($token_data['created']) ? $token_data['created'] : 'N/A'));
            // error_log('  Token origin: ' . (isset($token_data['origin']) ? $token_data['origin'] : 'N/A'));
            // error_log('  Current merchant ID: ' . $this->merchant_id);

            // 获取customer信息以确认merchant
            if (isset($token_data['customer'])) {
                $customer_id = $token_data['customer'];
                // error_log('Fetching customer data to verify merchant: ' . $customer_id);
                $customer_response = $this->makeApiRequest('/customers/' . $customer_id, 'GET', array(), true);

                if (isset($customer_response['response']['data'][0]['merchant'])) {
                    $token_merchant = $customer_response['response']['data'][0]['merchant'];
                    // error_log('Token merchant (from customer): ' . $token_merchant);
                    // error_log('Current config merchant: ' . $this->merchant_id);

                    if ($token_merchant !== $this->merchant_id) {
                        // error_log('ERROR: Merchant mismatch! Token belongs to ' . $token_merchant . ' but trying to use with ' . $this->merchant_id);
                        throw new Exception('Token belongs to a different merchant account');
                    }
                } elseif (isset($customer_response['data'][0]['merchant'])) {
                    $token_merchant = $customer_response['data'][0]['merchant'];
                    // error_log('Token merchant (from customer): ' . $token_merchant);
                    // error_log('Current config merchant: ' . $this->merchant_id);

                    if ($token_merchant !== $this->merchant_id) {
                        // error_log('ERROR: Merchant mismatch! Token belongs to ' . $token_merchant . ' but trying to use with ' . $this->merchant_id);
                        throw new Exception('Token belongs to a different merchant account');
                    }
                }
            }

            // 获取订单信息
            if (!function_exists('wc_get_order')) {
                throw new Exception('WooCommerce not active');
            }

            $order = wc_get_order($order_id);
            if (!$order || !is_a($order, 'WC_Order')) {
                throw new Exception('Invalid order ID');
            }

            // 准备交易数据
            $amount = $order->get_total();
            $amount_in_cents = intval($amount * 100);
            $billing_street_parts = array_filter(array(
                sanitize_text_field($order->get_billing_address_1()),
                sanitize_text_field($order->get_billing_address_2()),
            ));
            $billing_street = !empty($billing_street_parts)
                ? implode(', ', $billing_street_parts)
                : '100 Queen Street West';

            // !!!关键：使用token的hash值，而不是token ID
            $token_hash = isset($token_data['token']) ? $token_data['token'] : null;
            if (!$token_hash) {
                // error_log('ERROR: Token hash not found in token data');
                throw new Exception('Invalid token data: missing token hash');
            }

            // error_log('Using token hash for payment: ' . $token_hash);

            $transaction_data = array(
                'merchant' => $this->merchant_id,
                'token' => $token_hash,  // 使用hash值，不是ID
                'total' => $amount_in_cents,
                'order' => (string) $order_id, // 订单绑定：供后续 verifyTransaction 校验交易归属本单
                'type' => 1, // Sale
                'origin' => 8, // API/Ecommerce origin (required)
                'first' => $this->billingFieldOrDefault($order->get_billing_first_name(), 'Customer'),
                'last' => $this->billingFieldOrDefault($order->get_billing_last_name(), 'Canada'),
                'address' => $billing_street,
                'city' => $this->billingFieldOrDefault($order->get_billing_city(), 'Toronto'),
                'state' => strtoupper($this->billingFieldOrDefault($order->get_billing_state(), 'ON')),
                'zip' => $this->normalizePostalCode($order->get_billing_postcode()),
                'country' => $this->convertCountryToAlpha3($this->billingFieldOrDefault($order->get_billing_country(), 'CA')),
            );

            $billing_email = sanitize_email($order->get_billing_email());
            $billing_phone = substr(preg_replace('/\D+/', '', $order->get_billing_phone()), 0, 15);

            if ($billing_email !== '') {
                $transaction_data['email'] = $billing_email;
            }

            if ($billing_phone !== '') {
                $transaction_data['phone'] = $billing_phone;
            }

            // error_log('Transaction data: ' . json_encode($transaction_data));

            // 创建交易（使用Private Key）
            $response = $this->makeApiRequest('/txns', 'POST', $transaction_data, true);
            // error_log('Transaction response: ' . json_encode($response));

            // 检查响应
            $transaction_id = null;
            if (isset($response['response']['data'][0]['id'])) {
                $transaction_id = $response['response']['data'][0]['id'];
            } elseif (isset($response['data'][0]['id'])) {
                $transaction_id = $response['data'][0]['id'];
            }

            if (!$transaction_id) {
                // 检查是否有错误
                if (isset($response['response']['errors']) && !empty($response['response']['errors'])) {
                    $error_msg = $response['response']['errors'][0]['msg'] ?? 'Unknown error';
                    throw new Exception('Payment failed: ' . $error_msg);
                } elseif (isset($response['errors']) && !empty($response['errors'])) {
                    $error_msg = $response['errors'][0]['msg'] ?? 'Unknown error';
                    throw new Exception('Payment failed: ' . $error_msg);
                }
                throw new Exception('Failed to create transaction');
            }

            // error_log('Transaction created successfully: ' . $transaction_id);

            return array(
                'status' => 'success',
                'message' => 'Payment processed successfully',
                'transactionId' => $transaction_id
            );

        } catch (Exception $e) {
            // error_log('ERROR paying with token: ' . $e->getMessage());
            return array(
                'status' => 'error',
                'message' => $e->getMessage()
            );
        }
    }

    /**
     * Return sanitized billing data or a Canadian fallback.
     *
     * @param mixed  $value Billing field value.
     * @param string $default Default value.
     * @return string
     */
    private function billingFieldOrDefault($value, $default) {
        $value = sanitize_text_field($value);
        return $value !== '' ? $value : $default;
    }

    /**
     * 将国家代码转换为 Bookiy 要求的 ISO 3166-1 alpha-3 格式。
     * WooCommerce 存储的是 alpha-2（如 CA / US / BR），Bookiy /txns 只接受 alpha-3（CAN / USA / BRA）。
     *
     * @param string $country 国家代码（alpha-2 或 alpha-3）
     * @return string alpha-3 国家代码
     */
    private function convertCountryToAlpha3($country) {
        $country = strtoupper(trim(sanitize_text_field($country)));
        if ($country === '') {
            return 'CAN';
        }
        // 已是 alpha-3 直接返回
        if (strlen($country) === 3) {
            return $country;
        }
        $map = array(
            'AD' => 'AND', 'AE' => 'ARE', 'AF' => 'AFG', 'AG' => 'ATG', 'AI' => 'AIA',
            'AL' => 'ALB', 'AM' => 'ARM', 'AO' => 'AGO', 'AQ' => 'ATA', 'AR' => 'ARG',
            'AS' => 'ASM', 'AT' => 'AUT', 'AU' => 'AUS', 'AW' => 'ABW', 'AX' => 'ALA',
            'AZ' => 'AZE', 'BA' => 'BIH', 'BB' => 'BRB', 'BD' => 'BGD', 'BE' => 'BEL',
            'BF' => 'BFA', 'BG' => 'BGR', 'BH' => 'BHR', 'BI' => 'BDI', 'BJ' => 'BEN',
            'BL' => 'BLM', 'BM' => 'BMU', 'BN' => 'BRN', 'BO' => 'BOL', 'BQ' => 'BES',
            'BR' => 'BRA', 'BS' => 'BHS', 'BT' => 'BTN', 'BV' => 'BVT', 'BW' => 'BWA',
            'BY' => 'BLR', 'BZ' => 'BLZ', 'CA' => 'CAN', 'CC' => 'CCK', 'CD' => 'COD',
            'CF' => 'CAF', 'CG' => 'COG', 'CH' => 'CHE', 'CI' => 'CIV', 'CK' => 'COK',
            'CL' => 'CHL', 'CM' => 'CMR', 'CN' => 'CHN', 'CO' => 'COL', 'CR' => 'CRI',
            'CU' => 'CUB', 'CV' => 'CPV', 'CW' => 'CUW', 'CX' => 'CXR', 'CY' => 'CYP',
            'CZ' => 'CZE', 'DE' => 'DEU', 'DJ' => 'DJI', 'DK' => 'DNK', 'DM' => 'DMA',
            'DO' => 'DOM', 'DZ' => 'DZA', 'EC' => 'ECU', 'EE' => 'EST', 'EG' => 'EGY',
            'EH' => 'ESH', 'ER' => 'ERI', 'ES' => 'ESP', 'ET' => 'ETH', 'FI' => 'FIN',
            'FJ' => 'FJI', 'FK' => 'FLK', 'FM' => 'FSM', 'FO' => 'FRO', 'FR' => 'FRA',
            'GA' => 'GAB', 'GB' => 'GBR', 'GD' => 'GRD', 'GE' => 'GEO', 'GF' => 'GUF',
            'GG' => 'GGY', 'GH' => 'GHA', 'GI' => 'GIB', 'GL' => 'GRL', 'GM' => 'GMB',
            'GN' => 'GIN', 'GP' => 'GLP', 'GQ' => 'GNQ', 'GR' => 'GRC', 'GS' => 'SGS',
            'GT' => 'GTM', 'GU' => 'GUM', 'GW' => 'GNB', 'GY' => 'GUY', 'HK' => 'HKG',
            'HM' => 'HMD', 'HN' => 'HND', 'HR' => 'HRV', 'HT' => 'HTI', 'HU' => 'HUN',
            'ID' => 'IDN', 'IE' => 'IRL', 'IL' => 'ISR', 'IM' => 'IMN', 'IN' => 'IND',
            'IO' => 'IOT', 'IQ' => 'IRQ', 'IR' => 'IRN', 'IS' => 'ISL', 'IT' => 'ITA',
            'JE' => 'JEY', 'JM' => 'JAM', 'JO' => 'JOR', 'JP' => 'JPN', 'KE' => 'KEN',
            'KG' => 'KGZ', 'KH' => 'KHM', 'KI' => 'KIR', 'KM' => 'COM', 'KN' => 'KNA',
            'KP' => 'PRK', 'KR' => 'KOR', 'KW' => 'KWT', 'KY' => 'CYM', 'KZ' => 'KAZ',
            'LA' => 'LAO', 'LB' => 'LBN', 'LC' => 'LCA', 'LI' => 'LIE', 'LK' => 'LKA',
            'LR' => 'LBR', 'LS' => 'LSO', 'LT' => 'LTU', 'LU' => 'LUX', 'LV' => 'LVA',
            'LY' => 'LBY', 'MA' => 'MAR', 'MC' => 'MCO', 'MD' => 'MDA', 'ME' => 'MNE',
            'MF' => 'MAF', 'MG' => 'MDG', 'MH' => 'MHL', 'MK' => 'MKD', 'ML' => 'MLI',
            'MM' => 'MMR', 'MN' => 'MNG', 'MO' => 'MAC', 'MP' => 'MNP', 'MQ' => 'MTQ',
            'MR' => 'MRT', 'MS' => 'MSR', 'MT' => 'MLT', 'MU' => 'MUS', 'MV' => 'MDV',
            'MW' => 'MWI', 'MX' => 'MEX', 'MY' => 'MYS', 'MZ' => 'MOZ', 'NA' => 'NAM',
            'NC' => 'NCL', 'NE' => 'NER', 'NF' => 'NFK', 'NG' => 'NGA', 'NI' => 'NIC',
            'NL' => 'NLD', 'NO' => 'NOR', 'NP' => 'NPL', 'NR' => 'NRU', 'NU' => 'NIU',
            'NZ' => 'NZL', 'OM' => 'OMN', 'PA' => 'PAN', 'PE' => 'PER', 'PF' => 'PYF',
            'PG' => 'PNG', 'PH' => 'PHL', 'PK' => 'PAK', 'PL' => 'POL', 'PM' => 'SPM',
            'PN' => 'PCN', 'PR' => 'PRI', 'PS' => 'PSE', 'PT' => 'PRT', 'PW' => 'PLW',
            'PY' => 'PRY', 'QA' => 'QAT', 'RE' => 'REU', 'RO' => 'ROU', 'RS' => 'SRB',
            'RU' => 'RUS', 'RW' => 'RWA', 'SA' => 'SAU', 'SB' => 'SLB', 'SC' => 'SYC',
            'SD' => 'SDN', 'SE' => 'SWE', 'SG' => 'SGP', 'SH' => 'SHN', 'SI' => 'SVN',
            'SJ' => 'SJM', 'SK' => 'SVK', 'SL' => 'SLE', 'SM' => 'SMR', 'SN' => 'SEN',
            'SO' => 'SOM', 'SR' => 'SUR', 'SS' => 'SSD', 'ST' => 'STP', 'SV' => 'SLV',
            'SX' => 'SXM', 'SY' => 'SYR', 'SZ' => 'SWZ', 'TC' => 'TCA', 'TD' => 'TCD',
            'TF' => 'ATF', 'TG' => 'TGO', 'TH' => 'THA', 'TJ' => 'TJK', 'TK' => 'TKL',
            'TL' => 'TLS', 'TM' => 'TKM', 'TN' => 'TUN', 'TO' => 'TON', 'TR' => 'TUR',
            'TT' => 'TTO', 'TV' => 'TUV', 'TW' => 'TWN', 'TZ' => 'TZA', 'UA' => 'UKR',
            'UG' => 'UGA', 'UM' => 'UMI', 'US' => 'USA', 'UY' => 'URY', 'UZ' => 'UZB',
            'VA' => 'VAT', 'VC' => 'VCT', 'VE' => 'VEN', 'VG' => 'VGB', 'VI' => 'VIR',
            'VN' => 'VNM', 'VU' => 'VUT', 'WF' => 'WLF', 'WS' => 'WSM', 'XK' => 'XXK',
            'YE' => 'YEM', 'YT' => 'MYT', 'ZA' => 'ZAF', 'ZM' => 'ZMB', 'ZW' => 'ZWE',
        );
        // 未知的二位国家码兜底为 CAN，避免向只接受 alpha-3 的 API 再次发送非法值。
        return isset($map[$country]) ? $map[$country] : 'CAN';
    }

    /**
     * Normalize Canadian postal codes and fall back when no postal code is available.
     *
     * @param mixed $postal_code Postal code.
     * @return string
     */
    private function normalizePostalCode($postal_code) {
        $postal_code = strtoupper(sanitize_text_field($postal_code));
        $compact_code = preg_replace('/[^A-Z0-9]/', '', $postal_code);

        if (preg_match('/^[A-Z]\d[A-Z]\d[A-Z]\d$/', $compact_code)) {
            return substr($compact_code, 0, 3) . ' ' . substr($compact_code, 3);
        }

        return $postal_code !== '' ? substr($postal_code, 0, 20) : 'M5H 2N2';
    }

    /**
     * 通过邮箱获取客户ID
     *
     * @param string $email 邮箱地址
     * @return string|null 客户ID
     */
    public function getCustomerIdByEmail($email) {
        // error_log('BookiyPaymentService - Get customer ID by email: ' . $email);

        try {
            // 搜索客户
            $response = $this->makeApiRequest('/customers?email=' . urlencode($email), 'GET');

            // 提取客户ID
            if (isset($response['response']['data'][0]['id'])) {
                return $response['response']['data'][0]['id'];
            } elseif (isset($response['data'][0]['id'])) {
                return $response['data'][0]['id'];
            }

            return null;

        } catch (Exception $e) {
            // error_log('ERROR getting customer ID: ' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * 直接保存PayFields返回的Token数据（无需Private Key）
     *
     * @param array $token_data Token数据
     * @param int $user_id 用户ID
     * @return array 响应数据
     */
    public function saveTokenFromPayFieldsData($token_data, $user_id) {
        // error_log('');
        // error_log('================================================================================');
        // error_log('BookiyPaymentService - SAVE TOKEN FROM PAYFIELDS DATA');
        // error_log('================================================================================');
        // error_log('User ID: ' . $user_id);
        // error_log('Token data: ' . json_encode($token_data, JSON_PRETTY_PRINT));

        try {
            // 验证必要字段
            if (!isset($token_data['token_id']) || empty($token_data['token_id'])) {
                throw new Exception('Missing token_id in token data');
            }

            // 如果 token_data 中包含 customer_id，同时保存 customer ID
            if (isset($token_data['customer_id']) && !empty($token_data['customer_id'])) {
                $customer_id = $token_data['customer_id'];
                $current_env = (strpos($this->api_base_url, 'test-api') !== false) ? 'test' : 'production';
                $meta_key = 'bookiy_customer_id_' . $current_env;

                // error_log('Saving customer ID to user meta: ' . $customer_id);
                update_user_meta($user_id, $meta_key, $customer_id);
                // error_log('Customer ID saved successfully');
            }

            // error_log('================================================================================');
            // error_log('TOKEN SAVE COMPLETED');
            // error_log('================================================================================');
            // error_log('');

            return array(
                'status' => 'success',
                'message' => 'Token saved successfully',
                'token_id' => $token_data['token_id']
            );

        } catch (Exception $e) {
            // error_log('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
            // error_log('ERROR SAVING TOKEN FROM PAYFIELDS DATA');
            // error_log('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
            // error_log('Error message: ' . $e->getMessage());
            // error_log('Error trace: ' . $e->getTraceAsString());
            // error_log('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
            // error_log('');

            return array(
                'status' => 'error',
                'message' => $e->getMessage()
            );
        }
    }
}
