<?php

/**
 * Class BookiyPaymentAPI
 *
 * REST API endpoints for Bookiy Payment processing
 */
class BookiyPaymentAPI {

    /**
     * Initialize the API endpoints
     */
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    /**
     * Register REST API routes
     */
    public function register_routes() {
        // Get payment configuration endpoint
        register_rest_route('bookiy-payment/v1', '/config', array(
            'methods' => 'POST',
            'callback' => array($this, 'get_payment_config'),
            'permission_callback' => '__return_true',
        ));

        // Create transaction session endpoint
        register_rest_route('bookiy-payment/v1', '/create-session', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_transaction_session'),
            'permission_callback' => '__return_true',
        ));

        // Receive webhook notification endpoint
        register_rest_route('bookiy-payment/v1', '/webhook', array(
            'methods' => 'POST',
            'callback' => array($this, 'receive_webhook'),
            'permission_callback' => '__return_true',
        ));

        // Update order status endpoint (for synchronous payment success)
        register_rest_route('bookiy-payment/v1', '/update-order', array(
            'methods' => 'POST',
            'callback' => array($this, 'update_order_status'),
            'permission_callback' => '__return_true',
        ));

        // Save payment token from PayFields response endpoint
        register_rest_route('bookiy-payment/v1', '/save-token-from-response', array(
            'methods' => 'POST',
            'callback' => array($this, 'save_token_from_response'),
            'permission_callback' => '__return_true',
        ));

        // Get saved tokens endpoint
        register_rest_route('bookiy-payment/v1', '/get-tokens', array(
            'methods' => 'POST',
            'callback' => array($this, 'get_saved_tokens'),
            'permission_callback' => '__return_true',
        ));

        // Pay with token endpoint
        register_rest_route('bookiy-payment/v1', '/pay-with-token', array(
            'methods' => 'POST',
            'callback' => array($this, 'pay_with_token'),
            'permission_callback' => '__return_true',
        ));

        // Get customer ID by email endpoint
        register_rest_route('bookiy-payment/v1', '/get-customer-id', array(
            'methods' => 'POST',
            'callback' => array($this, 'get_customer_id_by_email'),
            'permission_callback' => '__return_true',
        ));

        // Save customer ID from transaction endpoint
        register_rest_route('bookiy-payment/v1', '/save-customer-id', array(
            'methods' => 'POST',
            'callback' => array($this, 'save_customer_id_from_transaction'),
            'permission_callback' => '__return_true',
        ));
    }

    /**
     * 安全：用 WooCommerce order_key 授权订单相关操作（支持游客结账）。
     * 校验通过返回订单对象，否则返回 false。
     *
     * @param mixed $order_id 订单ID
     * @param mixed $key      请求中携带的 order_key
     * @return WC_Order|false
     */
    private function verify_order_key($order_id, $key) {
        if (!function_exists('wc_get_order') || empty($order_id) || empty($key)) {
            return false;
        }
        $order = wc_get_order($order_id);
        if (!$order || !is_a($order, 'WC_Order')) {
            return false;
        }
        if (!hash_equals((string) $order->get_order_key(), (string) $key)) {
            return false;
        }
        return $order;
    }

    /**
     * 标准化的拒绝响应。
     */
    private function deny($message = 'Unauthorized', $code = 403) {
        return new WP_REST_Response(array(
            'status' => 'error',
            'message' => $message
        ), $code);
    }

    /**
     * Get payment configuration callback
     *
     * @param WP_REST_Request $request REST request object
     * @return WP_REST_Response REST response object
     */
    public function get_payment_config($request) {
        $data = $request->get_json_params();
        $order_id = isset($data['orderId']) ? sanitize_text_field($data['orderId']) : null;
        $key = isset($data['order_key']) ? sanitize_text_field($data['order_key']) : '';

        // 安全：必须携带有效 order_key，否则任何人都能凭订单ID读取金额/邮箱等信息。
        if (!$this->verify_order_key($order_id, $key)) {
            return $this->deny('Invalid order key');
        }

        // 安全：用户上下文一律取当前登录用户，忽略前端传入的 userId。
        $user_id = get_current_user_id();

        // Initialize payment service
        $payment_service = new BookiyPaymentService();

        // Get payment configuration (pass user_id)
        $response = $payment_service->getPaymentConfig($order_id, $user_id);

        // Return response
        $status_code = ($response['status'] === 'success') ? 200 : 500;
        return new WP_REST_Response($response, $status_code);
    }

    /**
     * Create transaction session callback
     *
     * @param WP_REST_Request $request REST request object
     * @return WP_REST_Response REST response object
     */
    public function create_transaction_session($request) {
        // 安全：该端点会向 Bookiy 创建交易会话，仅允许已登录用户调用（前端正常流程并不使用它）。
        if (!is_user_logged_in()) {
            return $this->deny('Authentication required', 401);
        }

        $data = $request->get_json_params();

        // Get session configuration if provided
        $config = isset($data['config']) ? $data['config'] : array();

        // Initialize payment service
        $payment_service = new BookiyPaymentService();

        // Create transaction session
        $response = $payment_service->createTransactionSession($config);

        // Return response
        $status_code = ($response['status'] === 'success') ? 200 : 500;
        return new WP_REST_Response($response, $status_code);
    }

    /**
     * Receive webhook notification callback
     *
     * @param WP_REST_Request $request REST request object
     * @return WP_REST_Response REST response object
     */
    public function receive_webhook($request) {
        // Get request data
        $notification_data = $request->get_json_params();

        // Log the webhook receipt
        // error_log('Bookiy Payment - Webhook received: ' . json_encode($notification_data));

        // Initialize payment service
        $payment_service = new BookiyPaymentService();

        // Process notification
        $response = $payment_service->processNotification($notification_data);

        // Return response
        $status_code = ($response['status'] === 'success') ? 200 : 400;
        return new WP_REST_Response($response, $status_code);
    }

    /**
     * Update order status synchronously (called from frontend after payment success)
     *
     * @param WP_REST_Request $request REST request object
     * @return WP_REST_Response REST response object
     */
    public function update_order_status($request) {
        // Get request data
        $data = $request->get_json_params();

        // Validate required fields
        if (!isset($data['orderId']) || !isset($data['transactionId'])) {
            return new WP_REST_Response(array(
                'status' => 'error',
                'message' => 'Missing required fields: orderId or transactionId'
            ), 400);
        }

        $order_id = sanitize_text_field($data['orderId']);
        $transaction_id = sanitize_text_field($data['transactionId']);
        $key = isset($data['order_key']) ? sanitize_text_field($data['order_key']) : '';

        // 安全：必须携带有效 order_key，否则任何人都能凭订单ID把订单标记为已支付。
        // 交易真实性（状态/金额/币种）由服务端向 Bookiy 复核，见 updateOrderStatusSync。
        if (!$this->verify_order_key($order_id, $key)) {
            return $this->deny('Invalid order key');
        }

        // error_log('Bookiy Payment - Synchronous order update requested: Order ID: ' . $order_id . ', Transaction ID: ' . $transaction_id);

        // Initialize payment service
        $payment_service = new BookiyPaymentService();

        // Update order status
        $response = $payment_service->updateOrderStatusSync($order_id, $transaction_id);

        // Return response
        $status_code = ($response['status'] === 'success') ? 200 : 400;
        return new WP_REST_Response($response, $status_code);
    }


    /**
     * Get saved payment tokens for user
     *
     * @param WP_REST_Request $request REST request object
     * @return WP_REST_Response REST response object
     */
    public function get_saved_tokens($request) {
        // 安全：只返回当前登录用户自己的卡片，忽略前端传入的 userId。
        $user_id = get_current_user_id();

        // For non-logged-in users, return empty tokens array
        if ($user_id <= 0) {
            return new WP_REST_Response(array(
                'status' => 'success',
                'tokens' => array()
            ), 200);
        }

        // Verify user
        $user = get_userdata($user_id);
        if (!$user) {
            return new WP_REST_Response(array(
                'status' => 'error',
                'message' => 'Invalid user'
            ), 400);
        }

        // error_log('Bookiy Payment - Fetching tokens from Bookiy API for user: ' . $user_id);

        // Initialize payment service
        $payment_service = new BookiyPaymentService();

        // Get tokens from Bookiy API
        try {
            $tokens = $payment_service->getTokensForUser($user->user_email);

            // error_log('Bookiy Payment - Retrieved ' . count($tokens) . ' tokens from Bookiy API');

            // 记录每个 Token 的详细信息
            /*
            foreach ($tokens as $index => $token) {
                error_log('Token ' . $index . ': ID=' . (isset($token['token_id']) ? $token['token_id'] : 'N/A') .
                         ', Last4=' . (isset($token['last4']) ? $token['last4'] : 'N/A') .
                         ', Brand=' . (isset($token['brand']) ? $token['brand'] : 'N/A'));
            }
            */

            return new WP_REST_Response(array(
                'status' => 'success',
                'tokens' => $tokens
            ), 200);
        } catch (Exception $e) {
            // error_log('Bookiy Payment - Error getting tokens: ' . $e->getMessage());
            return new WP_REST_Response(array(
                'status' => 'error',
                'message' => $e->getMessage()
            ), 500);
        }
    }

    /**
     * Pay with saved token
     *
     * @param WP_REST_Request $request REST request object
     * @return WP_REST_Response REST response object
     */
    public function pay_with_token($request) {
        $data = $request->get_json_params();

        // Validate required fields
        if (!isset($data['orderId']) || !isset($data['tokenId'])) {
            return new WP_REST_Response(array(
                'status' => 'error',
                'message' => 'Missing required fields: orderId or tokenId'
            ), 400);
        }

        $order_id = sanitize_text_field($data['orderId']);
        $token_id = sanitize_text_field($data['tokenId']);
        $key = isset($data['order_key']) ? sanitize_text_field($data['order_key']) : '';

        // 安全：使用保存的卡必须已登录，且必须携带有效 order_key。
        // token 是否归属当前用户由服务端 payWithToken() 进一步校验。
        $user_id = get_current_user_id();
        if ($user_id <= 0) {
            return $this->deny('Authentication required', 401);
        }
        if (!$this->verify_order_key($order_id, $key)) {
            return $this->deny('Invalid order key');
        }

        // error_log('Bookiy Payment - Pay with token: Order ID: ' . $order_id . ', Token ID: ' . $token_id);

        // 验证 Token ID 格式
        if (empty($token_id) || !is_string($token_id)) {
            // error_log('Bookiy Payment - ERROR: Invalid token ID format');
            // error_log('Token ID: ' . var_export($token_id, true));
            return new WP_REST_Response(array(
                'status' => 'error',
                'message' => 'Invalid token ID format'
            ), 400);
        }

        // 检查 Token ID 是否以 t1_tok_ 开头
        if (strpos($token_id, 't1_tok_') !== 0) {
            // error_log('Bookiy Payment - WARNING: Token ID may have invalid format');
            // error_log('Token ID: ' . $token_id);
        }

        // Initialize payment service
        $payment_service = new BookiyPaymentService();

        // Process payment with token (服务端校验 token 归属当前用户)
        $response = $payment_service->payWithToken($order_id, $token_id, $user_id);

        // Return response
        $status_code = ($response['status'] === 'success') ? 200 : 400;
        return new WP_REST_Response($response, $status_code);
    }

    /**
     * Get customer ID by email
     *
     * @param WP_REST_Request $request REST request object
     * @return WP_REST_Response REST response object
     */
    public function get_customer_id_by_email($request) {
        // 安全：要求登录，且只允许查询本人邮箱（忽略前端传入的 email），
        // 避免探测任意邮箱是否已存在 Bookiy customer。
        $user = wp_get_current_user();
        if (!$user || !$user->ID) {
            return $this->deny('Authentication required', 401);
        }

        $email = sanitize_email($user->user_email);

        // error_log('Bookiy Payment - Get customer ID by email: ' . $email);

        // Initialize payment service
        $payment_service = new BookiyPaymentService();

        // Get customer ID
        try {
            $customer_id = $payment_service->getCustomerIdByEmail($email);

            if ($customer_id) {
                return new WP_REST_Response(array(
                    'status' => 'success',
                    'customerId' => $customer_id
                ), 200);
            } else {
                return new WP_REST_Response(array(
                    'status' => 'error',
                    'message' => 'Customer not found'
                ), 404);
            }
        } catch (Exception $e) {
            // error_log('Bookiy Payment - Error getting customer ID: ' . $e->getMessage());
            return new WP_REST_Response(array(
                'status' => 'error',
                'message' => $e->getMessage()
            ), 500);
        }
    }

    /**
     * Save payment token from PayFields response
     *
     * @param WP_REST_Request $request REST request object
     * @return WP_REST_Response REST response object
     */
    public function save_token_from_response($request) {
        $data = $request->get_json_params();

        // Validate required fields
        if (!isset($data['tokenData'])) {
            return new WP_REST_Response(array(
                'status' => 'error',
                'message' => 'Missing required field: tokenData'
            ), 400);
        }

        // 安全：只能保存到当前登录用户名下，忽略前端传入的 userId。
        $user_id = get_current_user_id();
        $token_data = $data['tokenData'];

        if ($user_id <= 0) {
            return $this->deny('Authentication required', 401);
        }

        // error_log('Bookiy Payment - Saving token from PayFields response for user: ' . $user_id);
        // error_log('Token data received: ' . json_encode($token_data, JSON_PRETTY_PRINT));

        // Initialize payment service
        $payment_service = new BookiyPaymentService();

        // Save token directly from PayFields data
        $response = $payment_service->saveTokenFromPayFieldsData($token_data, $user_id);

        // Return response
        $status_code = ($response['status'] === 'success') ? 200 : 400;
        return new WP_REST_Response($response, $status_code);
    }

    /**
     * Save customer ID from transaction
     *
     * @param WP_REST_Request $request REST request object
     * @return WP_REST_Response REST response object
     */
    public function save_customer_id_from_transaction($request) {
        $data = $request->get_json_params();

        // Validate required fields
        if (!isset($data['transactionId'])) {
            return new WP_REST_Response(array(
                'status' => 'error',
                'message' => 'Missing required field: transactionId'
            ), 400);
        }

        $transaction_id = sanitize_text_field($data['transactionId']);

        // 安全：只能写入当前登录用户自己的 meta，忽略前端传入的 userId/userEmail，
        // 杜绝攻击者用一笔有效交易ID覆盖任意用户的 customer id。
        $user_id = get_current_user_id();
        if ($user_id <= 0) {
            return $this->deny('Authentication required', 401);
        }
        $user = get_userdata($user_id);
        $user_email = $user ? $user->user_email : null;

        // Initialize payment service
        $payment_service = new BookiyPaymentService();

        // Save customer ID from transaction (仅限当前登录用户)
        $response = $payment_service->saveCustomerIdFromTransaction($transaction_id, $user_id, $user_email);

        // Return response
        $status_code = ($response['status'] === 'success') ? 200 : 400;
        return new WP_REST_Response($response, $status_code);
    }
}
