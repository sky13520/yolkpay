<?php

class YolkpayHostedPage {

    public function __construct() {
        add_action('init', array($this, 'add_rewrite_rules'));
        add_filter('template_include', array($this, 'load_custom_template'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_custom_assets'));
        add_filter('query_vars', array($this, 'register_query_var'));
    }

    public function add_rewrite_rules() {
        // 添加重写规则
        add_rewrite_rule(
            '^safe-checkout/?$',
            'index.php?yolkpay_checkout_page=1',
            'top'
        );

        // 添加带订单ID的重写规则（路径参数方式）
        add_rewrite_rule(
            '^safe-checkout/([^/]+)/?$',
            'index.php?yolkpay_checkout_page=1&order_id=$matches[1]',
            'top'
        );

        // 添加带订单ID的重写规则（查询参数方式）
        add_rewrite_rule(
            '^safe-checkout/?\?order_id=([^/]+)$',
            'index.php?yolkpay_checkout_page=1&order_id=$matches[1]',
            'top'
        );

        // 注册查询变量
        add_rewrite_tag('%yolkpay_checkout_page%', '([^&]+)');
        add_rewrite_tag('%order_id%', '([^&]+)');
    }

    public function register_query_var($vars) {
        $vars[] = 'yolkpay_checkout_page';
        $vars[] = 'order_id';
        return $vars;
    }

    public function load_custom_template($template) {
        if (get_query_var('yolkpay_checkout_page')) {
            // 移除用户登录检查，允许游客访问

            // 返回插件内的自定义模板
            $custom_template = YOLKPAY_HOSTED_PLUGIN_PATH . 'templates/bookiy-checkout.php';
            if (file_exists($custom_template)) {
                return $custom_template;
            }
        }
        return $template;
    }

    public function enqueue_custom_assets() {
        if (get_query_var('yolkpay_checkout_page')) {
            // 移除用户登录检查，允许游客访问

            // 加载新的 Bookiy CSS
            wp_enqueue_style('bookiy-checkout-css',
                YOLKPAY_HOSTED_PLUGIN_URL . 'assets/css/bookiy-checkout.css',
                array(), YOLKPAY_HOSTED_VERSION
            );

            // 获取订单ID（尝试多种方式）
            $order_id = get_query_var('order_id');

            // 如果通过查询变量没有获取到，尝试直接从请求中获取
            if (empty($order_id) || $order_id === '$1') {
                if (isset($_GET['order_id'])) {
                    $order_id = sanitize_text_field($_GET['order_id']);
                }
            }

            // 安全：用 WooCommerce order_key 校验访问权限（支持游客）。
            // 不匹配则不暴露任何订单数据（金额/商品/账单地址），避免凭订单ID遍历泄露隐私。
            $order_key = isset($_GET['key']) ? sanitize_text_field($_GET['key']) : '';
            $order_valid = false;
            if (!empty($order_id) && function_exists('wc_get_order')) {
                $order = wc_get_order($order_id);
                if ($order && is_a($order, 'WC_Order') && hash_equals((string) $order->get_order_key(), (string) $order_key)) {
                    $order_valid = true;
                }
            }

            if (!$order_valid) {
                $order_id = null;
                $order_key = '';
            }

            // 根据订单ID获取订单金额（仅在 key 校验通过后）
            $amount = $this->get_order_amount($order_id);

            // 获取订单商品信息
            $items = $this->get_order_items($order_id);

            // 获取账单地址信息
            $billing_address = $this->get_billing_address($order_id);

            // 加载新的 Bookiy JavaScript
            wp_enqueue_script('bookiy-checkout-js',
                YOLKPAY_HOSTED_PLUGIN_URL . 'assets/js/bookiy-checkout.js',
                array(), YOLKPAY_HOSTED_VERSION, true
            );

            // 将金额数据和商品信息传递给前端
            $options = get_option('yolkpay_payment_options');
            $debug_enabled = isset($options['enable_debug_log']) && $options['enable_debug_log'] === '1';
            $countdown_seconds = isset($options['redirect_countdown_seconds']) ? intval($options['redirect_countdown_seconds']) : 5;

            wp_localize_script(
                'bookiy-checkout-js',
                'yolkpay_checkout_data',
                array(
                    'amount' => $amount,
                    'order_id' => $order_id,
                    'order_key' => $order_key, // 传给前端，REST 调用时回传以做授权
                    'nonce' => wp_create_nonce('wp_rest'), // WP REST nonce：登录用户 Cookie 认证必需
                    'items' => $items,
                    'billing_address' => $billing_address,
                    'user_id' => get_current_user_id(), // 添加用户ID
                    'debug_enabled' => $debug_enabled, // 添加调试开关
                    'countdown_seconds' => $countdown_seconds, // 添加倒计时秒数
                    'i18n' => array(
                        'loading' => __('Loading payment form...', 'yolkpay-hosted'),
                        'loadingError' => __('Unable to load payment form:', 'yolkpay-hosted'),
                        'refreshPage' => __('Please refresh the page and try again.', 'yolkpay-hosted'),
                        'checkPaymentInfo' => __('Please check your payment information', 'yolkpay-hosted'),
                        'submitPayment' => __('Submit Payment', 'yolkpay-hosted'),
                        'processing' => __('Processing...', 'yolkpay-hosted'),
                        'retryPayment' => __('Retry Payment', 'yolkpay-hosted'),
                        'paymentSuccess' => __('Payment Successful!', 'yolkpay-hosted'),
                        'transactionId' => __('Transaction ID:', 'yolkpay-hosted'),
                        'updatingOrder' => __('Updating order status...', 'yolkpay-hosted'),
                        'redirecting' => __('Redirecting to order confirmation page in', 'yolkpay-hosted'),
                        'seconds' => __('seconds', 'yolkpay-hosted'),
                        'paymentFailed' => __('Payment Failed', 'yolkpay-hosted'),
                        'checkInfoRetry' => __('Please check your payment information and try again', 'yolkpay-hosted'),
                        'error' => __('Error:', 'yolkpay-hosted'),
                        'payFieldsNotInit' => __('PayFields not initialized, please refresh the page', 'yolkpay-hosted'),
                        'invalidMerchant' => __('Invalid payment configuration: Missing Merchant ID', 'yolkpay-hosted'),
                        'invalidApiKey' => __('Invalid payment configuration: Missing API Key, please check backend settings', 'yolkpay-hosted'),
                        'selectPaymentMethod' => __('Select Payment Method', 'yolkpay-hosted'),
                        'useNewCard' => __('Use a new card', 'yolkpay-hosted'),
                        'continue' => __('Continue', 'yolkpay-hosted'),
                        'confirmPayment' => __('Confirm Payment', 'yolkpay-hosted'),
                        'payingWith' => __('Paying with saved card', 'yolkpay-hosted'),
                        'amount' => __('Amount', 'yolkpay-hosted'),
                        'confirmPay' => __('Confirm and Pay', 'yolkpay-hosted'),
                        'cancel' => __('Cancel', 'yolkpay-hosted'),
                    )
                )
            );

            // 添加调试日志
            /*
            error_log("YolkPay Hosted: Localized script data: " . json_encode(array(
                'amount' => $amount,
                'order_id' => $order_id,
                'items' => $items,
                'billing_address' => $billing_address,
                'user_id' => get_current_user_id()
            )));
            */
        }
    }

    /**
     * 根据订单ID获取订单金额
     *
     * @param string $order_id 订单ID
     * @return array 包含货币和金额的数组
     */
    private function get_order_amount($order_id) {
        // 添加调试日志
        // error_log("YolkPay Hosted: Attempting to get amount for order ID: " . var_export($order_id, true));

        // 检查是否为WooCommerce订单
        if (!empty($order_id) && function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);

            if ($order && is_a($order, 'WC_Order')) {
                // 获取订单总金额（保持原始格式，不乘以100）
                $amount_value = $order->get_total();

                // 添加调试日志
                // error_log("YolkPay Hosted: Order ID: $order_id, Currency: " . $order->get_currency() . ", Amount: $amount_value");

                return array(
                    'currency' => $order->get_currency(),
                    'value' => strval($amount_value)
                );
            } else {
                // error_log("YolkPay Hosted: Failed to get valid order object for order ID: $order_id");
            }
        } else {
            // error_log("YolkPay Hosted: Either order ID is empty or wc_get_order function does not exist. Order ID: " . var_export($order_id, true));
        }

        // 默认金额
        // error_log("YolkPay Hosted: Using default amount for order ID: $order_id");
        return array(
            'currency' => 'USD',
            'value' => '60.00'
        );
    }

    /**
     * 根据订单ID获取订单商品信息
     *
     * @param string $order_id 订单ID
     * @return array 商品信息数组
     */
    private function get_order_items($order_id) {
        // 检查是否为WooCommerce订单
        if (!empty($order_id) && function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);

            if ($order && is_a($order, 'WC_Order')) {
                $items = array();

                // 遍历订单中的商品
                foreach ($order->get_items() as $item_id => $item) {
                    $product = $item->get_product();
                    $items[] = array(
                        'name' => $item->get_name(),
                        'quantity' => $item->get_quantity(),
                        'price' => $item->get_total() / $item->get_quantity(), // 单价
                        'total' => $item->get_total(), // 小计
                        'image' => $product ? wp_get_attachment_image_url($product->get_image_id(), 'thumbnail') : ''
                    );
                }

                return $items;
            }
        }

        // 默认商品信息
        return array(
            array(
                'name' => 'Classic Woman Bag',
                'quantity' => 1,
                'price' => '60.00',
                'total' => '60.00',
                'image' => 'https://mdn.alipayobjects.com/portal_pdqp4x/afts/file/A*H8M9RrxlArAAAAAAAAAAAAAAAQAAAQ'
            )
        );
    }

    /**
     * 根据订单ID获取账单地址信息
     *
     * @param string $order_id 订单ID
     * @return array 账单地址信息数组
     */
    private function get_billing_address($order_id) {
        $billing_address = array(
            'firstName' => '',
            'lastName' => '',
            'address1' => '',
            'address2' => '',
            'city' => '',
            'state' => '',
            'zip' => '',
            'country' => '',
            'email' => '',
            'phone' => ''
        );

        // 检查是否为WooCommerce订单
        if (!empty($order_id) && function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);

            if ($order && is_a($order, 'WC_Order')) {
                $order_address = array(
                    'firstName' => sanitize_text_field($order->get_billing_first_name()),
                    'lastName' => sanitize_text_field($order->get_billing_last_name()),
                    'address1' => sanitize_text_field($order->get_billing_address_1()),
                    'address2' => sanitize_text_field($order->get_billing_address_2()),
                    'city' => sanitize_text_field($order->get_billing_city()),
                    'state' => strtoupper(sanitize_text_field($order->get_billing_state())),
                    'zip' => $this->normalize_postal_code($order->get_billing_postcode()),
                    'country' => strtoupper(sanitize_text_field($order->get_billing_country())),
                    'email' => sanitize_email($order->get_billing_email()),
                    'phone' => preg_replace('/\D+/', '', $order->get_billing_phone())
                );

                foreach ($order_address as $field => $value) {
                    if ($value !== '') {
                        $billing_address[$field] = $value;
                    }
                }
            }
        }

        return $billing_address;
    }

    /**
     * Normalize postal codes while preserving non-Canadian formats.
     *
     * @param string $postal_code Postal code.
     * @return string
     */
    private function normalize_postal_code($postal_code) {
        $postal_code = strtoupper(sanitize_text_field($postal_code));
        $compact_code = preg_replace('/[^A-Z0-9]/', '', $postal_code);

        if (preg_match('/^[A-Z]\d[A-Z]\d[A-Z]\d$/', $compact_code)) {
            return substr($compact_code, 0, 3) . ' ' . substr($compact_code, 3);
        }

        return substr($postal_code, 0, 20);
    }

    /**
     * 更新订单状态
     *
     * @param string $order_id 订单ID
     * @param string $status 状态
     */
    private function update_order_status($order_id, $status) {
        // 检查WooCommerce是否激活
        if (!function_exists('wc_get_order')) {
            // error_log("YolkPay Hosted Payment - WooCommerce not active, cannot update order status");
            return;
        }

        // error_log("YolkPay Hosted Payment - Updating order status for order ID: " . $order_id . " to status: " . $status);

        try {
            $order = wc_get_order($order_id);
            if ($order && is_a($order, 'WC_Order')) {
                $current_status = $order->get_status();
                // error_log("YolkPay Hosted Payment - Current order status: " . $current_status);

                // 只有当订单状态为待付款或on-hold时才更新
                if (($current_status === 'pending' || $current_status === 'on-hold') && $status === 'success') {
                    // 更新订单状态为已完成
                    $order->update_status('completed', __('Payment completed via YolkPay Hosted Payment.', 'yolkpay-hosted'));
                    // error_log("YolkPay Hosted Payment - Order status updated to completed for order: " . $order_id);

                    // 减少库存
                    if (function_exists('wc_reduce_stock_levels')) {
                        wc_reduce_stock_levels($order_id);
                        // error_log("YolkPay Hosted Payment - Stock reduced for order: " . $order_id);
                    }
                } else {
                    // error_log("YolkPay Hosted Payment - Order not updated. Current status: " . $current_status . ", Target status: " . $status);
                }
            } else {
                // error_log("YolkPay Hosted Payment - Failed to get valid order object for order ID: " . $order_id);
                // error_log("YolkPay Hosted Payment - Order object type: " . (is_object($order) ? get_class($order) : gettype($order)));
            }
        } catch (Exception $e) {
            // error_log("YolkPay Hosted Payment - Exception updating order status: " . $e->getMessage());
            // error_log("Exception trace: " . $e->getTraceAsString());
        }
    }
}
