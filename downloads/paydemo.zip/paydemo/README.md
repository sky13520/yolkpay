# PayDemo — Payrix 支付集成演示

基于 **FastAPI** 的 Payrix 支付网关集成演示项目，使用 PayFields 提供卡片支付体验。

## 支付流程

```
用户访问页面 → 后端创建 txnSession → 加载 PayFields SDK → 用户填写卡片 → 支付结果回调
```

1. 前端请求后端配置，获取商户信息和 API 地址
2. 后端使用**私钥**创建 Payrix `txnSession`，返回 session key
3. 前端加载 PayFields SDK，配置 session key
4. 用户在模态框中填写卡号、有效期、CVV、持卡人姓名
5. 支付成功后，前端调用 `/api/update-order` 记录交易
6. Payrix 异步发送 Webhook 到 `/api/webhook` 更新交易状态

## 项目结构

```
├── app/
│   ├── __init__.py
│   ├── config.py           # 环境配置（Pydantic Settings）
│   ├── main.py             # FastAPI 应用入口 + API 路由
│   └── services/
│       ├── __init__.py
│       └── payrix.py       # Payrix API 客户端（会话创建、Webhook 处理）
├── static/
│   ├── css/
│   │   └── style.css       # 页面样式
│   ├── js/
│   │   └── payment.js      # 支付前端逻辑
│   └── payframe.html       # 支付页面入口
├── payment.html            # 简化版支付演示页面（直接配置）
├── requirements.txt        # Python 依赖
├── .env.example            # 环境变量模板
└── README.md
```

## 快速开始

### 1. 配置环境变量

```bash
cp .env.example .env
```

编辑 `.env`，填入你的 Payrix 商户凭证：

| 变量 | 说明 |
|------|------|
| `MERCHANT_ID` | 商户 ID（测试以 `t1_mer_` 开头） |
| `API_KEY` | 公钥（测试以 `t1_pub_` 开头） |
| `PRIVATE_API_KEY` | 私钥（测试以 `t1_pri_` 开头，仅服务端使用） |
| `ENVIRONMENT` | `test` 或 `production` |

### 2. 安装依赖

```bash
pip install -r requirements.txt
```

### 3. 启动服务

```bash
uvicorn app.main:app --reload --port 8000
```

访问 `http://localhost:8000` 进入支付页面。

## API 接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/` | 首页 |
| GET | `/api/config` | 获取前端配置（商户 ID、环境、API 地址） |
| POST | `/api/create-session` | 创建 Payrix txnSession |
| POST | `/api/webhook` | 接收 Payrix 异步支付通知 |
| GET | `/api/transaction/{txn_id}` | 查询单笔交易状态 |
| GET | `/api/transactions` | 查询所有交易记录 |
| POST | `/api/update-order` | 前端支付成功后更新订单状态 |

## 环境

- **测试环境**: `https://test-api.payrixcanada.com`
- **生产环境**: `https://api.payrixcanada.com`
- **Python**: 3.10+
- **依赖**: FastAPI, Uvicorn, httpx, pydantic-settings
