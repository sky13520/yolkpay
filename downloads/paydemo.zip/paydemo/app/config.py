from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    merchant_id: str = ""
    api_key: str = ""
    private_api_key: str = ""
    environment: str = "test"

    @property
    def api_base_url(self) -> str:
        if self.environment == "production":
            return "https://api.payrixcanada.com"
        return "https://test-api.payrixcanada.com"

    @property
    def payfields_script_url(self) -> str:
        return f"{self.api_base_url}/payFieldsScript"

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}


settings = Settings()
