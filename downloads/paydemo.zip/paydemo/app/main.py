import time
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.services.payrix import PayrixService

app = FastAPI(title="PayDemo")

# Serve static frontend files
HERE = Path(__file__).resolve().parent
STATIC_DIR = HERE.parent / "static"
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/payframe.html")
async def payframe():
    """Serve the payment page at /payframe.html."""
    return HTMLResponse((STATIC_DIR / "payframe.html").read_text())

# ---------------------------------------------------------------------------
# In-memory transaction store
# ---------------------------------------------------------------------------
# Keyed by transaction ID, stores status updates from webhook + frontend
transactions: dict[str, dict] = {}


def _env_badge() -> str:
    return "PRODUCTION" if settings.environment == "production" else "TEST"


# ---------------------------------------------------------------------------
# API endpoints
# ---------------------------------------------------------------------------


@app.get("/")
async def root():
    """Landing page."""
    return HTMLResponse("hello，we are bookiy.com test system")


@app.get("/api/config")
async def get_config():
    """Return the public-facing Payrix configuration for the frontend."""
    svc = PayrixService()
    return {"status": "success", "config": svc.get_public_config()}


@app.post("/api/create-session")
async def create_session():
    """Create a Payrix txnSession and return the session key."""
    svc = PayrixService()
    try:
        result = await svc.create_session()
        return result
    except Exception as exc:
        return JSONResponse(status_code=500, content={"status": "error", "message": str(exc)})


# ---------------------------------------------------------------------------
# Webhook — async notification from Payrix
# ---------------------------------------------------------------------------


@app.post("/api/webhook")
async def webhook(request: Request):
    """
    Receive async payment notifications from Payrix.

    Payrix sends webhooks when transaction status changes
    (approved / settled / declined / failed).  The status is
    persisted in the in-memory store so it can be queried later.
    """
    payload = await request.json()
    svc = PayrixService()
    result = await svc.process_webhook(payload)

    # Persist to in-memory store (merge so we don't lose frontend-submitted data)
    txn_id = result.get("transactionId")
    if txn_id:
        if txn_id not in transactions:
            transactions[txn_id] = {"transactionId": txn_id, "source": "webhook"}
        transactions[txn_id].update(
            {
                "status": result["status"],
                "message": result.get("message", ""),
                "updated_at": time.time(),
                "webhook_payload": payload,
            }
        )

    http_status = 200 if result["status"] == "success" else 400
    return JSONResponse(status_code=http_status, content=result)


# ---------------------------------------------------------------------------
# Transaction query
# ---------------------------------------------------------------------------


@app.get("/api/transaction/{txn_id}")
async def get_transaction(txn_id: str):
    """Query the status of a transaction (from in-memory store)."""
    txn = transactions.get(txn_id)
    if not txn:
        return JSONResponse(
            status_code=404,
            content={"status": "not_found", "transactionId": txn_id},
        )
    return {"status": "ok", "transaction": txn}


@app.get("/api/transactions")
async def list_transactions():
    """List all known transactions."""
    return {
        "status": "ok",
        "environment": _env_badge(),
        "transactions": list(transactions.values()),
    }


# ---------------------------------------------------------------------------
# Order update — called from frontend after PayFields onSuccess
# ---------------------------------------------------------------------------


@app.post("/api/update-order")
async def update_order(request: Request):
    """
    Synchronous order-update called from the frontend after PayFields
    reports a successful payment.
    """
    data = await request.json()
    order_id = data.get("orderId", "")
    txn_id = data.get("transactionId", "")

    if not order_id or not txn_id:
        return JSONResponse(
            status_code=400,
            content={"status": "error", "message": "Missing orderId or transactionId"},
        )

    # Persist to in-memory store
    transactions[txn_id] = {
        "transactionId": txn_id,
        "orderId": order_id,
        "status": "approved",
        "source": "frontend",
        "updated_at": time.time(),
    }

    return {
        "status": "success",
        "transactionId": txn_id,
        "orderId": order_id,
        "message": "Order recorded",
    }
