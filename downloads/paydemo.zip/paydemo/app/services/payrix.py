import httpx
from app.config import settings


class PayrixService:
    """Payrix API client — mirrors PayrixPaymentService from the WordPress plugin."""

    def __init__(self):
        self.api_base_url = settings.api_base_url
        self.merchant_id = settings.merchant_id
        self.api_key = settings.api_key
        self.private_api_key = settings.private_api_key

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    def get_public_config(self) -> dict:
        """Return the public-facing configuration the frontend needs.

        NOTE: apiKey is intentionally excluded — the frontend uses a
        txnSessionKey created server-side via the private key instead.
        """
        return {
            "merchant": self.merchant_id,
            "environment": "PRODUCTION" if settings.environment == "production" else "TEST",
            "apiBaseUrl": self.api_base_url,
            "payfieldsScriptUrl": settings.payfields_script_url,
        }

    # ------------------------------------------------------------------
    # Session management
    # ------------------------------------------------------------------

    async def create_session(
        self, duration: int = 8, max_times_approved: int = 4, max_times_use: int = 10
    ) -> dict:
        """Create a txnSession that the frontend can use with PayFields."""
        data = {
            "merchant": self.merchant_id,
            "configurations": {
                "duration": duration,
                "maxTimesApproved": max_times_approved,
                "maxTimesUse": max_times_use,
            },
        }
        result = await self._request("/txnSessions", "POST", data, use_private_key=True)

        item = self._extract_first(result)
        if item and "key" in item:
            return {"status": "success", "sessionKey": item["key"], "sessionId": item["id"]}

        raise ValueError("Failed to create transaction session")

    # ------------------------------------------------------------------
    # Webhook
    # ------------------------------------------------------------------

    async def process_webhook(self, payload: dict) -> dict:
        """
        Handle an incoming Payrix webhook notification.

        Payrix webhooks carry a transaction 'id' and a 'status'.
        Common statuses: approved, settled, declined, failed, pending.
        """
        txn_id = payload.get("id", "")
        status = payload.get("status", "")

        if status in ("approved", "settled"):
            return {
                "status": "success",
                "transactionId": txn_id,
                "message": f"Payment {status}",
            }
        elif status == "declined":
            return {
                "status": "declined",
                "transactionId": txn_id,
                "message": "Payment declined by issuer",
            }
        elif status == "failed":
            return {
                "status": "failed",
                "transactionId": txn_id,
                "message": payload.get("failureMessage", "Payment failed"),
            }
        else:
            return {
                "status": "pending",
                "transactionId": txn_id,
                "message": f"Status: {status}",
            }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _request(
        self, endpoint: str, method: str = "GET", data: dict | None = None, use_private_key: bool = False
    ) -> dict:
        """Low-level HTTP call to the Payrix API."""
        url = f"{self.api_base_url}{endpoint}"
        api_key = self.private_api_key if use_private_key else self.api_key

        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "APIKEY": api_key,
        }

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.request(method, url, headers=headers, json=data)
            resp.raise_for_status()
            return resp.json()

    @staticmethod
    def _extract_first(response: dict) -> dict | None:
        """Drill into Payrix paginated response to get the first data item."""
        for key in ("data",):
            items = response.get(key) or response.get("response", {}).get(key)
            if isinstance(items, list) and items:
                return items[0]
        return None
