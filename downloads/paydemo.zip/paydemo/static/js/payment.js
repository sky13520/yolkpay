/**
 * PayDemo — Payment frontend
 *
 * Flow:
 *   1. Fetch config from backend       GET /api/config
 *   2. Create transaction session      POST /api/create-session
 *   3. Pre-set PayFields.config with txnSessionKey BEFORE loading script
 *   4. Load PayFields SDK  (script sees valid session key, no error)
 *   5. Show order summary + "Pay Now" button
 *   6. User clicks "Pay Now" → modal opens → set callbacks & fields
 *   7. User fills card → submits → onSuccess / onFailure
 *   8. On success → POST /api/update-order → close modal → show result
 */
(function () {
  "use strict";

  var CONFIG_URL = "/api/config";
  var CREATE_SESSION_URL = "/api/create-session";
  var UPDATE_ORDER_URL = "/api/update-order";
  var TRANSACTIONS_URL = "/api/transactions";

  var merchantId = "";
  var payfieldsReady = false;
  var currentAmount = 5.00;

  var $ = function (id) { return document.getElementById(id); };
  var show = function (el) { el.style.display = ""; };
  var hide = function (el) { el.style.display = "none"; };

  /* ================================================================ */
  /*  API helpers                                                     */
  /* ================================================================ */
  function apiPost(url, data) {
    return fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    }).then(function (r) { return r.json(); });
  }

  function apiGet(url) {
    return fetch(url).then(function (r) { return r.json(); });
  }

  /* ================================================================ */
  /*  Utility                                                         */
  /* ================================================================ */
  function nowISO() {
    return new Date().toISOString().replace("T", " ").slice(0, 19);
  }

  function statusClass(status) {
    if (status === "success" || status === "approved") return "status-success";
    if (status === "declined" || status === "failed") return "status-declined";
    if (status === "pending") return "status-pending";
    return "";
  }

  function fmtDollar(amount) {
    return "$" + parseFloat(amount).toFixed(2);
  }

  /* ================================================================ */
  /*  Amount control                                                  */
  /* ================================================================ */
  function updateAmount(val) {
    currentAmount = parseFloat(val) || 0;
    $("item1-price").textContent = fmtDollar(currentAmount);
    $("total-price").textContent = fmtDollar(currentAmount);
  }

  /* ================================================================ */
  /*  Modal control                                                   */
  /* ================================================================ */
  function openModal() {
    show($("payment-modal"));

    if (!payfieldsReady) {
      // Double rAF: let browser render modal before PayFields wires iframes
      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          finishPayFieldsInit();
          payfieldsReady = true;
        });
      });
    }
  }

  function closeModal() {
    hide($("payment-modal"));
  }

  window.PayDemo = {
    openModal: openModal,
    closeModal: closeModal,
    loadHistory: loadHistory,
    showResult: showResult,
    updateAmount: updateAmount
  };

  /* ================================================================ */
  /*  Step 1 — fetch config from backend                              */
  /* ================================================================ */
  function fetchConfig() {
    return apiGet(CONFIG_URL).then(function (body) {
      if (body.status !== "success" || !body.config)
        throw new Error(body.message || "Invalid config response");
      return body.config;
    });
  }

  /* ================================================================ */
  /*  Step 2 — create transaction session (server-side, uses priv key)*/
  /* ================================================================ */
  function createSession() {
    return apiPost(CREATE_SESSION_URL, {}).then(function (body) {
      if (body.status !== "success" || !body.sessionKey)
        throw new Error(body.message || "Session creation failed");
      return body;
    });
  }

  /* ================================================================ */
  /*  Step 3 — load PayFields SDK, THEN set config on real object     */
  /* ================================================================ */
  function bootstrapPayFields(sessionKey, merchant, scriptUrl) {
    // The PayFields script does `var PayFields = function(){...}()` which
    // replaces window.PayFields with a brand-new object, wiping any
    // pre-set config. So we must set config AFTER the script loads.
    return new Promise(function (resolve, reject) {
      var id = "payfields-script";
      if (document.getElementById(id)) {
        return resolve();
      }
      var s = document.createElement("script");
      s.id = id;
      s.src = scriptUrl;
      s.onload = function () {
        // Script has already run and created the real PayFields object.
        // The jQuery ready -> ready() -> s() -> isValid() chain already
        // fired and FAILED because config was all nulls at that point.
        // Set config/fields/callbacks on the real object, then manually
        // re-trigger ready() to create the iframe and add fields.
        var pf = window.PayFields;
        if (pf && pf.config) {
          pf.config.txnSessionKey = sessionKey;
          pf.config.merchant = merchant;
          pf.config.amount = Math.round(currentAmount * 100);

          pf.fields = [
            { type: "number",     element: "#card-number" },
            { type: "cvv",        element: "#card-cvv" },
            { type: "name",       element: "#card-name" },
            { type: "expiration", element: "#card-expiration" },
          ];

          // Restrict accepted cards to 16-digit brands only
          pf.config.allowedCardBrands = ["VISA", "MASTERCARD", "DISCOVER"];

          pf.onSuccess = function (response) {
            var txn = (response.data && response.data[0]) || response;
            var txnId = txn.id || "N/A";
            closeModal();
            apiPost(UPDATE_ORDER_URL, { transactionId: txnId, orderId: "demo-" + Date.now() })
              .then(function () { showResult("success", txnId, "Payment completed successfully."); })
              .catch(function () { showResult("success", txnId, "Payment completed (order sync deferred)."); });
          };

          pf.onFailure = function (response) {
            var msg =
              (response.errors && response.errors.map(function (e) { return e.msg || e.message; }).join("; ")) ||
              response.message ||
              "Payment was declined. Please try a different card.";
            $("form-error").textContent = msg;
            show($("form-error"));
            enableSubmit();
          };

          pf.onValidationFailure = function () {
            $("form-error").textContent = "Please check your card details. Card number should be 15-16 digits, expiration must be valid, and CVV must be 3-4 digits.";
            show($("form-error"));
            enableSubmit();
          };

          // Re-trigger initialisation now that config is valid.
          // This calls s() -> appendIframe() -> isValid() passes ->
          // iframe created -> onload -> addFields() injects card iframes.
          pf.ready();
        }
        resolve();
      };
      s.onerror = function () { reject(new Error("Failed to load PayFields script")); };
      document.body.appendChild(s);
    });
  }

  /* ================================================================ */
  /*  Step 4 — final init when modal renders (amount + submit)        */
  /* ================================================================ */
  function finishPayFieldsInit() {
    var pf = window.PayFields;
    if (!pf) return;

    // Update amount in case user changed it before opening modal
    pf.config.amount = Math.round(currentAmount * 100);

    // Re-set callbacks (closure references are current)
    pf.onSuccess = function (response) {
      var txn = (response.data && response.data[0]) || response;
      var txnId = txn.id || "N/A";
      closeModal();
      apiPost(UPDATE_ORDER_URL, { transactionId: txnId, orderId: "demo-" + Date.now() })
        .then(function () { showResult("success", txnId, "Payment completed successfully."); })
        .catch(function () { showResult("success", txnId, "Payment completed (order sync deferred)."); });
    };

    pf.onFailure = function (response) {
      var msg =
        (response.errors && response.errors.map(function (e) { return e.msg || e.message; }).join("; ")) ||
        response.message ||
        "Payment was declined. Please try a different card.";
      $("form-error").textContent = msg;
      show($("form-error"));
      enableSubmit();
    };

    pf.onValidationFailure = function () {
      $("form-error").textContent = "Please check your card details. Card number should be 15-16 digits, expiration must be valid, and CVV must be 3-4 digits.";
      show($("form-error"));
      enableSubmit();
    };

    setTimeout(function () { $("submit-btn").disabled = false; }, 800);
  }

  /* ================================================================ */
  /*  Submit handler                                                  */
  /* ================================================================ */
  function enableSubmit() {
    $("submit-btn").disabled = false;
    $("btn-text").textContent = "Pay Now";
    hide($("btn-spinner"));
  }

  function disableSubmit() {
    $("submit-btn").disabled = true;
    $("btn-text").textContent = "Processing\u2026";
    show($("btn-spinner"));
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (!window.PayFields) return;
    hide($("form-error"));
    disableSubmit();
    try {
      PayFields.submit();
    } catch (err) {
      $("form-error").textContent = err.message;
      show($("form-error"));
      enableSubmit();
    }
  }

  /* ================================================================ */
  /*  Result display                                                  */
  /* ================================================================ */
  function showResult(status, txnId, message) {
    $("result-icon").textContent =
      status === "success" || status === "approved" ? "\u2705" :
      status === "pending" ? "\u23F3" : "\u274C";
    $("result-title").textContent =
      status === "success" || status === "approved" ? "Payment Successful" :
      status === "pending" ? "Payment Pending" : "Payment Failed";

    $("result-status").textContent = status;
    $("result-status").className = statusClass(status);
    $("result-txn-id").textContent = txnId;
    $("result-amount").textContent = fmtDollar(currentAmount);
    $("result-time").textContent = nowISO();
    $("result-message").textContent = message || "";

    var retryBtn = $("result-retry");
    retryBtn.style.display = (status === "success" || status === "approved") ? "none" : "";
    retryBtn.onclick = function () { location.reload(); };

    var checkBtn = $("result-check-status");
    checkBtn.style.display = (txnId && txnId !== "N/A") ? "" : "none";
    checkBtn.onclick = function () {
      checkBtn.disabled = true;
      checkBtn.textContent = "Checking\u2026";
      apiGet("/api/transaction/" + txnId).then(function (data) {
        var whRow = $("result-webhook-row");
        var whEl  = $("result-webhook");
        if (data.status === "ok" && data.transaction) {
          show(whRow);
          whEl.textContent = data.transaction.status || "unknown";
          whEl.className = statusClass(data.transaction.status);
        } else {
          show(whRow);
          whEl.textContent = "Not yet received";
          whEl.className = "";
        }
        checkBtn.disabled = false;
        checkBtn.textContent = "Check Webhook Status";
      });
    };

    hide($("loading"));
    hide($("order-summary"));

    var rc = $("result");
    rc.className = "card";
    if (status === "success" || status === "approved")       rc.style.borderLeft = "4px solid #22c55e";
    else if (status === "pending")                            rc.style.borderLeft = "4px solid #f59e0b";
    else                                                      rc.style.borderLeft = "4px solid #ef4444";
    show(rc);
    loadHistory();
  }

  /* ================================================================ */
  /*  Transaction history                                             */
  /* ================================================================ */
  function loadHistory() {
    apiGet(TRANSACTIONS_URL).then(function (data) {
      var list = $("history-list");
      if (!data.transactions || data.transactions.length === 0) {
        list.innerHTML = '<div class="history-empty">No transactions yet</div>';
        show($("history-section"));
        return;
      }
      list.innerHTML = data.transactions.slice().reverse().map(function (t) {
        return '<div class="history-item" onclick="window.PayDemo.showResult(\'' +
          t.status + "','" + t.transactionId + "','" + (t.message || "") + '\')">' +
          '<div class="h-row"><span class="' + statusClass(t.status) + '"><strong>' + t.status +
          '</strong></span><span class="h-txn-id">' +
          (t.transactionId || "").slice(0, 16) + '\u2026</span></div>' +
          '<div style="font-size:0.8rem;color:#9ca3af;margin-top:4px">' +
          (t.source || "unknown") + " \u00b7 " +
          (t.updated_at ? new Date(t.updated_at * 1000).toLocaleString() : "") + "</div></div>";
      }).join("");
      show($("history-section"));
    });
  }

  /* ================================================================ */
  /*  Bootstrap                                                       */
  /* ================================================================ */
  function boot() {
    var cfg, sessionKey;

    fetchConfig()
      .then(function (c) {
        cfg = c;
        merchantId = cfg.merchant;

        // Environment badge
        var badge = $("env-badge");
        var isProd = cfg.environment === "PRODUCTION";
        badge.textContent = isProd ? "LIVE  PRODUCTION" : "SANDBOX  TEST";
        badge.className = "env-badge " + (isProd ? "env-production" : "env-test");
        show(badge);

        // Order summary
        updateAmount(5.00);
        show($("order-summary"));

        // Step 2: create session (server-side, uses private key)
        return createSession();
      })
      .then(function (sessionResult) {
        sessionKey = sessionResult.sessionKey;
        // Step 3: pre-set txnSessionKey & merchant, then load PayFields script
        return bootstrapPayFields(sessionKey, cfg.merchant, cfg.payfieldsScriptUrl);
      })
      .then(function () {
        // Bind UI
        $("submit-btn").addEventListener("click", handleSubmit);
        $("payment-modal").addEventListener("click", function (e) {
          if (e.target === this) closeModal();
        });
        hide($("loading"));
        loadHistory();
      })
      .catch(function (err) {
        $("fatal-error-message").textContent = err.message;
        hide($("loading"));
        show($("fatal-error"));
      });
  }

  boot();
})();
